<script type="text/javascript">
	
	var map;
	var geocoder;
	var marker;

      function initMap() {
		var mapLayer = document.getElementById("map-layer");
		var centerCoordinates = new google.maps.LatLng(-23.5730000,-46.6737500);
		var defaultOptions = { center: centerCoordinates, zoom: 15 };
		map = new google.maps.Map(mapLayer, defaultOptions);
		geocoder = new google.maps.Geocoder();
		var ultimainfowindow = null;
		
		/*var icons = {
          arvore: {
            icon: 'markers/arvore.png'
          },
          buraco: {
            icon: 'markers/buraco.png'
          },
          iluminacao: {
            icon: 'markers/iluminacao.png'
          }
		  obra: {
            icon: 'markers/obra.png'
          }
		  sinalizacao: {
            icon: 'markers/sinalizacao.png'
          }
        };*/
		
		
		<?php 
            if(!empty($endereco)) {

                foreach($endereco as $k=>$v) {
					
					if(file_exists('./uploads/'.$endereco[$k]["cd_ocorrencia"].'.jpg') )$imagem =  './uploads/'.$endereco[$k]["cd_ocorrencia"].'.jpg' ;
					else $imagem = 'uploads/_noimg.jpg';
        ?>  
					//geocoder.geocode( { 'address': '<?php echo 'brasil, sp, são paulo '.$endereco[$k]["bairro"].' '. $endereco[$k]["rua"].' '. $endereco[$k]["numero"]  ; ?>' }, function(LocationResult, status) {
						
					(function () {
					
							//var latitude = LocationResult[0].geometry.location.lat();
							//var longitude = LocationResult[0].geometry.location.lng();
					
							var latitude = <?php echo $endereco[$k]["latitude"]; ?>;
							var longitude = <?php echo $endereco[$k]["longitude"]; ?>;
					
				
					
					
						
							<?php $contador = $contador + 1; ?>
						
							//if (<?php echo $endereco[$k]["status"] ?> == 1){
								//google.maps.event.addDomListener(window, 'load', function() {
								
									var icon = {
										url: 'markers/<?php
									
											switch ($endereco[$k]["tema"]) {
												case "acessibilidade":
													echo "roxo";
													break;
												case "areas_verdes":
													echo "verde";
													break;
												case "seguranca_publica":
													echo "amarelo";
													break;
												case "transito":
													echo "vermelho";
													break;
												case "uso_irregular_do_solo":
													echo "azul";
													break;
												case "zeladoria_urbana":
													echo "laranja";
													break;
												default:
													echo "preto";
													break;
											}
									
										?>.png', // url
										scaledSize: new google.maps.Size(50, 50), // scaled size
										origin: new google.maps.Point(0,0), // origin
										anchor: new google.maps.Point(25, 50) // anchor
									};
								
									marker = new google.maps.Marker({
										position: new google.maps.LatLng(latitude, longitude),
										map: map,
										title: '<?php
										
											switch ($endereco[$k]["bairro"]) {
														case "jardim_america":
															echo "Jardim América";
															break;
														case "jardim_europa":
															echo "Jardim Europa";
															break;
														case "jardim_paulista":
															echo "Jardim Paulista";
															break;
														default:
															echo "Jardim Paulistano";
															break;
											}
											echo ', '.$endereco[$k]["rua"].', '.$endereco[$k]["numero"]; ?>',
										icon: icon
									});
									
									
									var contentString = '<div id="<?php echo $endereco[$k]["cd_ocorrencia"]?>" style="min-height: 100px; min-width: 100px; text-align: center;"> <a href="caso.php?cd_ocorrencia=<?php echo $endereco[$k]["cd_ocorrencia"]?>" style="display: block;"><span id="divImagemOcorrencia<?php echo $endereco[$k]["cd_ocorrencia"]?>" style="background-position: center; background-size: contain; background-repeat: no-repeat; width: 200px; height: 200px; display: inline-block;"></span><br><?php 
									
									echo $endereco[$k]["assunto"].'<br>';
									
									switch ($endereco[$k]["bairro"]) {
										case "jardim_america":
											echo "Jardim América";
											break;
										case "jardim_europa":
											echo "Jardim Europa";
											break;
										case "jardim_paulista":
											echo "Jardim Paulista";
											break;
										default:
											echo "Jardim Paulistano";
											break;
									}
									
									$data = date("d/m/Y", strtotime($endereco[$k]["data"]));
								
									echo ', '.$endereco[$k]["rua"].', '.$endereco[$k]["numero"].'<br>'.$data.'<br>';
									
									switch ($endereco[$k]["tema"]) {
										case "acessibilidade":
											echo "Acessibilidade";
											break;
										case "areas_verdes":
											echo "Áreas Verdes";
											break;
										case "seguranca_publica":
											echo "Seguranca Pública";
											break;
										case "transito":
											echo "Trânsito";
											break;
										case "uso_irregular_do_solo":
											echo "Uso Irregular do Solo";
											break;
										case "zeladoria_urbana":
											echo "Zeladoria Urbana";
											break;
										default:
											echo "Outros";
											break;
									}
									
									?></a></div>';
									var novainfowindow = new google.maps.InfoWindow({
										content: contentString
									});
									
									google.maps.event.addListener(marker, 'click', function() {
										if (ultimainfowindow)
											ultimainfowindow.close();
										ultimainfowindow = novainfowindow;
										novainfowindow.open(map, this);
										setTimeout(function () {
										document.getElementById("divImagemOcorrencia<?php echo $endereco[$k]["cd_ocorrencia"]?>").style.backgroundImage = "url(<?php echo $imagem; ?>)";
										}, 300);
									});
								//});
							//} // if (<?php echo $endereco[$k]["status"] ?> == 1){ 
						
						
						
						//else alert("Geocode failed, status="+status);
				
					})();
					
	    <?php
                }
				//echo $contador;
            }
	    ?>
		  /*
		  var trafficLayer = new google.maps.TrafficLayer();
          trafficLayer.setMap(map);
		  */
      }
    </script>
    <script async defer
		src="https://maps.googleapis.com/maps/api/js?key=<?php echo AIzaSyA6ysBoiWNEiQKRzPgymJroG_j_U2xPnnM; ?>&callback=initMap">
    </script>