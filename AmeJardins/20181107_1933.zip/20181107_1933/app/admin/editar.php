<?php 

	
	$cd_ocorrencia					= $_REQUEST['cd_ocorrencia'];
	$email 							= $_REQUEST['email'];
	$assunto						= $_REQUEST['assunto'];
	$mensagem						= $_REQUEST['mensagem'];
	$rua							= $_REQUEST['rua'];
	$numero							= $_REQUEST['numero'];
	$bairro  						= $_REQUEST['bairro'];
	$tema 							= $_REQUEST['tema'];
	$data							= $_REQUEST['data'];
	$status							= $_REQUEST['status'];
	$view							= $_REQUEST['view'];
	$adm_assunto					= $_REQUEST['adm_assunto'];
	$adm_orgao_responsavel			= $_REQUEST['adm_orgao_responsavel'];
	$adm_modo_de_envio				= $_REQUEST['adm_modo_de_envio'];
	$adm_data_de_envio				= $_REQUEST['adm_data_de_envio'];
	$adm_historico					= $_REQUEST['adm_historico'];
	$adm_data_conclusao				= $_REQUEST['adm_data_conclusao'];
	
			$conexao = mysqli_connect("ocorrenciamap.mysql.dbaas.com.br","ocorrenciamap","UBgIDXaIYih","ocorrenciamap") or die ("A conexão não foi executada com sucesso");
			$consulta = "UPDATE ocorrencia SET adm_assunto = '$adm_assunto', adm_orgao_responsavel = '$adm_orgao_responsavel', 
						 adm_modo_de_envio = '$adm_modo_de_envio', adm_data_de_envio = '$adm_data_de_envio', adm_historico = '$adm_historico', status = $status,
						 adm_data_conclusao = '$adm_data_conclusao'
						 WHERE cd_ocorrencia = $cd_ocorrencia";
			$resultado = mysqli_query($conexao, $consulta) or die ("Houve erro na gravação dos dados, por favor, clique em voltar e verifique os campos obrigatórios!");
			
			echo "<h1 align='center'>Caso editado com sucesso!</h1><br><a href=\"#\" onclick=\"window.history.go(-2);\" align='center' style='text-decoration: none'><p style='font-size: 25px;'>VOLTAR</p></a>";
			
			;
?> 
