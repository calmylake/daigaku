<html>
<head>
<meta charset="utf-8">
<style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #bbbbbb;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #eaeaea;
}
</style>
</head>
<body>

<?php

		$chnome 		= $_REQUEST['nome'];
		$chassociado	= $_REQUEST['associado'];
		$chemail 		= $_REQUEST['email'];
		$chassunto		= $_REQUEST['assunto'];
		$chmensagem		= $_REQUEST['mensagem'];
		$chendereco		= $_REQUEST['endereco'];
		$chbairro		= $_REQUEST['bairro'];
		$chtema 		= $_REQUEST['tema'];
		$chdata			= $_REQUEST['data'];
		$chstatus		= $_REQUEST['status'];
		$chview			= $_REQUEST['view'];
		$where			= $_REQUEST['where'];
		
?>
<a href="index.php">voltar ao mapa</a>
<h2 style="text-align:center;">Relatório</h2>
<form action="relatorio.php" method="get">
<input disabled checked type="checkbox">Código
<input <?php if($chnome == 1){echo "checked";} ?> type="checkbox" value="1" name="nome">Nome
<input <?php if($chassociado == 1){echo "checked";} ?>  type="checkbox" value="1" name="associado">Associado
<input <?php if($chemail == 1){echo "checked";} ?>  type="checkbox" value="1" name="email">E-mail
<input <?php if($chassunto == 1){echo "checked";} ?>  type="checkbox" value="1" name="assunto">Assunto
<input <?php if($chmensagem == 1){echo "checked";} ?>  type="checkbox" value="1" name="mensagem">Mensagem
<input <?php if($chendereco == 1){echo "checked";} ?>  type="checkbox" value="1" name="endereco">Endereço
<input <?php if($chbairro == 1){echo "checked";} ?>  type="checkbox" value="1" name="bairro">Bairro
<input <?php if($chtema == 1){echo "checked";} ?>  type="checkbox" value="1" name="tema">Tema
<input <?php if($chdata == 1){echo "checked";} ?>  type="checkbox" value="1" name="data">Data
<input <?php if($chstatus == 1){echo "checked";} ?>  type="checkbox" value="1" name="status">Status
<input <?php if($chview == 1){echo "checked";} ?>  type="checkbox" value="1" name="view">Visualizações
<input type="submit" value="FILTRAR">
</form>


<?php

echo "<table>
	  <tr>
			  <th>Código</th>";
		if($chnome == 1)
		echo "<th>Nome</th>";
		if($chassociado == 1)
		echo "<th>Associado</th>";
		if($chemail == 1)
		echo "<th>E-mail</th>";
		if($chassunto == 1)
		echo "<th>Assunto</th>";
		if($chmensagem == 1)
		echo "<th>Mensagem</th>";
		if($chendereco == 1)
		echo "<th>Endereço</th>";
		if($chbairro == 1)
		echo "<th>Bairro</th>";
		if($chtema == 1)
		echo "<th>Tema</th>";
		if($chdata == 1)
		echo "<th>ata</th>";
		if($chstatus == 1)
		echo "<th>Status</th>";
		if($chview == 1)
		echo "<th>Visualizações</th>";

	include "conexao.php";
	
	$consulta = 
		"select cd_ocorrencia, nome, associado, email, assunto, mensagem, numero, rua, bairro, data, tema, status, view
		from ocorrencia ".$where." order by data desc";




	$resultado = mysqli_query($conexao, $consulta) or die ("Não foi possível realizar a consulta ao banco de dados");
	
	echo "<div id='content3'>";

	while ($linha=mysqli_fetch_array($resultado)) { 
		
		$cd_ocorrencia  = $linha['cd_ocorrencia'];
		$nome 			= $linha['nome'];
		$associado		= $linha['associado'];
		$email 			= $linha['email'];
		$assunto		= $linha['assunto'];
		$mensagem		= $linha['mensagem'];
		$rua			= $linha['rua'];
		$numero			= $linha['numero'];
		$bairro  		= $linha['bairro'];
		$tema 			= $linha['tema'];
		$data			= $linha['data'];
		$status			= $linha['status'];
		$view			= $linha['view'];
		
		if ($status == 1) $stringstatus = "Administrativa";
		else $stringstatus = "Pública";
		
		if ($associado == "nao") {
			$associado = "Não";
			
		} else if ($associado == "sim") {
			$associado = "Sim";
		} else {
			$associado = "Quero me associar";
		}
		
		switch ($bairro) {
			case "jardim_america":
				$bairro = "Jardim América";
				$cor_bairro = "steelBlue";
				break;
			case "jardim_europa":
				$bairro = "Jardim Europa";
				$cor_bairro = "darkRed";
				break;
			case "jardim_paulista":
				$bairro = "Jardim Paulista";
				$cor_bairro = "darkGreen";
				break;
			case "jardim_paulistano":
				$bairro = "Jardim Paulistano";
				$cor_bairro = "darkOrange";
		}
		
		switch ($tema) {
			case "acessibilidade":
				$tema = "Acessibilidade";
				$cor_tema = "purple";
				break;
			case "areas_verdes":
				$tema = "Áreas Verdes";
				$cor_tema = "green";
				break;
			case "seguranca_publica":
				$tema = "Seguranca Pública";
				$cor_tema = "goldenRod";
				break;
			case "transito":
				$tema = "Trânsito";
				$cor_tema = "red";
				break;
			case "uso_irregular_do_solo":
				$tema = "Uso Irregular do Solo";
				$cor_tema = "blue";
				break;
			case "zeladoria_urbana":
				$tema = "Zeladoria Urbana";
				$cor_tema = "orange";
				break;
			case "outros":
				$tema = "Outros";
				$cor_tema = "black";
				break;
		}
		
		$datanova = date("d/m/Y", strtotime($data));
		
		if($status == 1) $status = "Administrativo";
		else $status = "Público";
		
	echo "
  
	  <tr>
		<th><a href=caso.php?cd_ocorrencia=$cd_ocorrencia>$cd_ocorrencia</a></th>
		";
		if($chnome == 1)
		echo "<th>$nome</th>";
		if($chassociado == 1)
		echo "<th>$associado</th>";
		if($chemail == 1)
		echo "<th>$email</th>";
		if($chassunto == 1)
		echo "<th>$assunto</th>";
		if($chmensagem == 1)
		echo "<th>$mensagem</th>";
		if($chendereco == 1) 
		echo "<th>$rua, $numero</th>";
		if($chbairro == 1)
		echo "<th><p style='color:" . $cor_bairro . ";'>$bairro</p></th>";
		if($chtema == 1)
		echo "<th><p style='color:" . $cor_tema . ";'>$tema</th>";
		if($chdata == 1)
		echo "<th>$datanova</th>";
		if($chstatus == 1)
		echo "<th>$status</th>";
		if($chview == 1)
		echo "<th>$view</th>";
		echo "
	  </tr>";
  
	

	}
	
	echo "</table>";
?>


</body>
</html>