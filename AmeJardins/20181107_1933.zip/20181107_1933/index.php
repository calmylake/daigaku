<?php

include "requerLogin.php";

require("dbcontroller.php");
$dbController = new DBController();
$where = '';
$query = "SELECT * FROM ocorrencia";
$endereco = $dbController->runQuery($query);
?>
<!DOCTYPE html>

<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <title>Ame Jardins</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        margin: 0;
        padding: 0;
      }
	  body {
		  font-family :Arial;
	  }
	  input {
		  background-color: transparent;
		  border-color: #000;
		  border: 1px solid;
		  border-radius: 2px;
		  -webkit-transition: background-color 200ms,color 200ms; /* For Safari 3.1 to 6.0 */
	      transition: background-color 200ms,color 200ms;
	  }
	  input:hover {
		  background-color: #000;
		  color: #fff;
		  
	  }
	  #map-layer {
		  padding-top: 300px;
		  margin: 0 auto;
		  max-width: 90%;
		  min-height: 90vh;
		  clear:both;
	  }
	  .menuspmais {
		  max-width: 800px;
		  padding:1em;
		  margin: 0 auto;
	  }
	  .formisso {
		  display: grid;
		  grid-template-columns: 1fr;
		  grid-gap: 5px;
	  }
	  .formisso p{
		  margin: 0;
	  }
	  .formisso select, .formisso input, form input {
		  width:100%;
	  }
	  @media(min-width:700px) {
		.filtro {
			width: 100%;
			float: left;
		}
		 #map-layer {
		  margin: 0 auto;
		  max-width: 70%;
		  min-height: 90vh;
		  clear:both;
	  }
		.formisso {
		  display: grid;
		  grid-template-columns: 1fr 1fr;
		  grid-gap:10px;
		  
		}
		.formisso select, .formisso input, form input {
		  width:100%;
	    }
		.total {
			grid-column:1/3	;
		}
		.footer-light-1{
			margin-top: 100px;
		}
		
	  }
    </style>
	 <!-- Bootstrap -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- font awesome for icons -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/animate.css" rel="stylesheet" type="text/css" media="screen"> 
        <!-- Revolution Style-sheet -->
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/css/settings.css">
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/css/rev-style.css">
        <!--owl carousel css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/yamm.css" rel="stylesheet" type="text/css">
        <!--cube css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css">
        <!-- custom css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/style.css?v=1" rel="stylesheet" type="text/css" media="screen">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
  </head>
  <body class="page-template page-template-fazemos page-template-fazemos-php page page-id-67 group-blog">
<script>
(function(i,s,o,g,r,a,m){
	i['GoogleAnalyticsObject']=r;
	i[r]=i[r]||function(){    (i[r].q=i[r].q||[]).push(arguments)    },
	i[r].l=1*new Date();
	a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];
	a.async=1;
	a.src=g;
	m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78743991-3', 'auto');
ga('send', 'pageview');

</script>
<div class="navbar navbar-default navbar-static-top yamm sticky " style="background-color:#ECF3F8" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="http://amejardins.com.br/wp-content/themes/ametema/img/logo.png" alt="Ame Jardins"></a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="http://amejardins.com.br">Home</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/quem-somos">Quem Somos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/o-que-fazemos">O Que Fazemos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/associe-se">Associe-se</a> 
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Jardins <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="http://amejardins.com.br/area-de-cobertura">Área de Cobertura</a></li>
                                <li><a href="http://amejardins.com.br/historia">História</a></li>
                                <li><a href="http://amejardins.com.br/dicas">Dicas</a></li>
                            </ul>
							
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/fale-conosco">Fale Conosco</a> 
                        </li> 
						<li class="">
                            <a href="http://amejardins.com.br/noticias">Notícias</a>
                        </li>
						<li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ocorrências <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="index.php">Mapa de Ocorrências</a></li>
                                <li><a href="criar.php">Registro de Ocorrência</a></li>
                            </ul>
							
                        </li>
						<li>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.facebook.com/AMEJARDINS" target="_blank"><i class="fa fa-facebook-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.youtube.com/channel/UCGG0rEpCbiJnOHCc1j55GLg" target="_blank"><i class="fa fa-youtube-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.instagram.com/amejardins/" target="_blank"><i class="fa fa-instagram"></i></a>
						</li>
						</ul>
                </div><!--/.nav-collapse -->
            </div><!--container-->
        </div><!--navbar-default--><style>
.tjust p{
	text-align:justify;
	padding-right:20px
}
</style>
 <div class="breadcrumb-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Mapa de ocorrências</h4>
                    </div>
                    
                </div>
            </div>
        </div><!--breadcrumbs-->
	<div class="divide40"></div>
	<div class="menuspmais">
		<div class="filtro" style="border-radius: 5px; border: #333 solid 2px; margin: 10px; padding: 1%;">
			<form class="formisso" action="filtrar.php" method="post">
				<p>
					<label>FILTRAR POR BAIRRO:</label>
					<select name="bairro" class="filtrarr">
						<option selected value>Todos</option>
						<option value="jardim_america">Jardim América</option>
						<option value="jardim_europa">Jardim Europa</option>
						<option value="jardim_paulista">Jardim Paulista</option>
						<option value="jardim_paulistano">Jardim Paulistano</option>
					</select>
				</p>
				<p>
				<label>FILTRAR POR TEMA:</label>
					<select name="tema" style="min-height: 20px;">
						<option selected value>Todos</option>
						<option value="acessibilidade">Acessibilidade</option>
						<option value="areas_verdes">Áreas Verdes</option>
						<option value="seguranca_publica">Segurança Pública</option>
						<option value="transito">Trânsito</option>
						<option value="uso_irregular_do_solo">Uso Irregular do Solo</option>
						<option value="zeladoria_urbana">Zeladoria Urbana</option>
						<option value="outros">Outros</option>
					</select>
				</p>
				<p>
				<label>FILTRAR POR STATUS:</label>
					<select name="fstatus">
						<option value="0">RECEBIDO</option>
						<option selected value="1">POSTADO</option>
						<option value="2">CONCLUÍDO</option>
						<option value="3">REJEITADO</option>
					</select>
				</p>
				<p class="total">
					<input class="filtrarr" type="submit" value="Filtrar">
				</p>
				</form>
			
		</div>
	</div>
    <div id="map-layer"></div>
    <div id="map"></div>
    <?php 
	$adm = 0;
	$contador = 0;
	include "scriptmapa.php";
	//echo $contador;
	?>
	
	<div class="divide60"></div>
        <footer class="footer-light-1">

			<div class="footer-copyright text-center">
                Ame Jardins &copy; <?php echo date('Y');?>. Todos os direitos reservados.
				<br>Rua Estados Unidos, 1.205 - Jd. América | CEP: 01427-000 |  (11) 3097-0911 | amejardins@amejardins.com.br
            </div>
        </footer><!--default footer end here-->

        <!--scripts and plugins -->
        <!--must need plugin jquery-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.min.js"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery-migrate.min.js"></script> 
        <!--bootstrap js plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>       
        <!--easing plugin for smooth scroll-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/wow.min.js" type="text/javascript"></script> 
        <!--owl carousel slider-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>        
        <!--customizable plugin edit according to your needs-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/revolution-custom.js"></script>
        <!--cube portfolio plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/cube-portfolio.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/pace.min.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/jasny/jasny-bootstrap.min.js"></script>

        
        <!--cantact form script-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jqBootstrapValidation.js" type="text/javascript"></script>
		<script>
			function processAutoheight(){
				
				$(".autoheight").each(function(){
					var maxHeight = 0;
					maxHeight = $(this).parents(".row").children(".hpadrao").outerHeight(true);
					$(this).height(maxHeight);
				})
					
			}


			$(document).ready(function() {

			$(".cep").inputmask({
				mask: '99999-999'
			});
			$(".cpf").inputmask({
				mask: '999.999.999-99'
			});
			$(".cnpj").inputmask({
				mask: '999.999.999/9999-99'
			});
			$(".tel").inputmask({
				mask: '(99) 9999-9999?9'
			});
    $(window).resize(function() { processAutoheight(); });

    $(document).resize(function() { processAutoheight(); });

    processAutoheight();
	$("#selectpss").on('change', function() {
		var valor = $(this).val();
		$(".formulario").hide();
		$("#"+valor).show();
	});
});
		</script>
  </body>
</html>
