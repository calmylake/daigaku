<?php

include "requerLogin.php";

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Ame Jardins</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        margin: 0;
        padding: 0;
      }
	  body {
		  font-family :Arial;
	  }
	  #map-layer {
		  margin: 0 auto;
		  max-width: 100%;
		  min-height: 90vh;
	  }
    </style>
	 <!-- Bootstrap -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- font awesome for icons -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/animate.css" rel="stylesheet" type="text/css" media="screen"> 
        <!-- Revolution Style-sheet -->
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/css/settings.css">
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/css/rev-style.css">
        <!--owl carousel css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/yamm.css" rel="stylesheet" type="text/css">
        <!--cube css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css">
        <!-- custom css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/style.css?v=1" rel="stylesheet" type="text/css" media="screen">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
  </head>
  <body class="page-template page-template-fazemos page-template-fazemos-php page page-id-67 group-blog">
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78743991-3', 'auto');
ga('send', 'pageview');

</script>
<div class="navbar navbar-default navbar-static-top yamm sticky " style="background-color:#ECF3F8" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="http://amejardins.com.br/wp-content/themes/ametema/img/logo.png" alt="Ame Jardins"></a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="http://amejardins.com.br">Home</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/quem-somos">Quem Somos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/o-que-fazemos">O Que Fazemos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/associe-se">Associe-se</a> 
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Jardins <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="http://amejardins.com.br/area-de-cobertura">Área de Cobertura</a></li>
                                <li><a href="http://amejardins.com.br/historia">História</a></li>
                                <li><a href="http://amejardins.com.br/dicas">Dicas</a></li>
                            </ul>
							
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/fale-conosco">Fale Conosco</a> 
                        </li> 
						<li class="">
                            <a href="http://amejardins.com.br/noticias">Notícias</a>
                        </li>
						<li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ocorrências <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="index.php">Mapa de Ocorrências</a></li>
                                <li><a href="criar.php">Registro de Ocorrência</a></li>
                            </ul>
							
                        </li>
						<li>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.facebook.com/AMEJARDINS" target="_blank"><i class="fa fa-facebook-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.youtube.com/channel/UCGG0rEpCbiJnOHCc1j55GLg" target="_blank"><i class="fa fa-youtube-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.instagram.com/amejardins/" target="_blank"><i class="fa fa-instagram"></i></a>
						</li>
						</ul>
                </div><!--/.nav-collapse -->
            </div><!--container-->
        </div><!--navbar-default--><style>
.tjust p{
	text-align:justify;
	padding-right:20px
}
</style>
 <div class="breadcrumb-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Registro de Ocorrência</h4>
                    </div>
                    
                </div>
            </div>
        </div><!--breadcrumbs-->
		<div class="divide80"></div>
		
			
		
		
<?php 

	$cd_ocorrencia = intval($_REQUEST['cd_ocorrencia']);
	$nome		= 	str_replace("'", "''", $_REQUEST['nome']);
	$associado	= 	str_replace("'", "''", $_REQUEST['associado']);
	$email	 	= 	str_replace("'", "''", $_REQUEST['email']);
	$assunto 	= 	str_replace("'", "''", $_REQUEST['assunto']);
	$mensagem 	= 	str_replace("'", "''", $_REQUEST['mensagem']);
	$numero 	= 	str_replace("'", "''", $_REQUEST['numero']);
	$rua 		= 	str_replace("'", "''", $_REQUEST['rua']);
	$bairro		= 	str_replace("'", "''", $_REQUEST['bairro']);
	$data	 	= 	str_replace("'", "''", $_REQUEST['data']);
	$tema	 	= 	str_replace("'", "''", $_REQUEST['tema']);
	$fotocaso 	= 	str_replace("'", "''", $_REQUEST['fotocaso']);
	$latitude 	= 	floatval($_REQUEST['coordenadalat']);
	$longitude 	= 	floatval($_REQUEST['coordenadalng']);
	

	?>
	
	
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6ysBoiWNEiQKRzPgymJroG_j_U2xPnnM&callback=initMap">
    </script>
	
	<?php
	$consulta = "INSERT INTO ocorrencia (nome, associado, email, assunto, mensagem, numero, rua, bairro, data, tema, latitude, longitude)
	VALUES ('$nome', '$associado', '$email', '$assunto', '$mensagem', '$numero', '$rua', '$bairro', '$data', '$tema' , '$latitude', '$longitude')";
	
	include "conexao.php";
	
	$resultado = mysqli_query($conexao, $consulta) or die ("Houve erro na gravação dos dados, por favor, clique em voltar e verifique os campos obrigatórios!");
	  
    $consulta = "SELECT cd_ocorrencia FROM  ocorrencia WHERE nome = '$nome' AND email = '$email' AND assunto = '$assunto' AND numero = '$numero' and rua = '$rua' AND bairro = '$bairro' AND data = '$data' AND tema = '$tema' AND latitude = '$latitude' AND longitude = '$longitude'";
	
	$resultado = mysqli_query($conexao, $consulta) or die ("<br>2Houve erro na gravação dos dados, por favor, clique em voltar e verifique os campos obrigatórios!");
	 list($cod_ocorrencia) = mysqli_fetch_row($resultado);
	$target_dir = "uploads/";
	$target_file = $target_dir . $cod_ocorrencia . '.jpg';
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	// Check if image file is a actual image or fake image
	if(isset($_POST["botao"])) {
		$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		if($check !== false) {
			//echo "File is an image - " . $check["mime"] . ".";
			$uploadOk = 1;
		} else {
			echo "O arquivo não é uma imagem.";
			$uploadOk = 0;
		}
	}
	// Check if file already exists
	if (file_exists($target_file)) {
		echo "Erro,o arquivo já existe.";
		$uploadOk = 0;
	}
	// Check file size
	if ($_FILES["fileToUpload"]["size"] > 5000000) {
		echo "Erro, arquivo com tamanho muito grande.";
		$uploadOk = 0;
	}
	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" ) {
		echo "ERRO, somente estes formatos de arquivos são permitidos: JPG, JPEG, PNG e GIF.";
		$uploadOk = 0;
	}
	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
		echo "Seu arquivo não foi enviado.";
	// if everything is ok, try to upload file
	} else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			//echo "O arquivo  ". basename( $_FILES["fileToUpload"]["name"]). " foi enviado.";
		} else {
			echo "Erro de envio do arquivo de imagem: ".basename( $_FILES["fileToUpload"]["name"]);
		}
	}
	  
	  
	echo "<h1 align='center'>Cadastro efetuado com sucesso!</h1><br><a href='index.php' align='center' style='text-decoration: none'><p style='font-size: 25px;'>VOLTAR</p></a>";
	
	  
	  
	  
	include "sendmail.php";
	
?>




















<div class="divide60"></div>
        <footer class="footer-light-1">

			<div class="footer-copyright text-center">
                Ame Jardins &copy; 2017. Todos os direitos reservados.
				<br>Rua Estados Unidos, 1.205 - Jd. América | CEP: 01427-000 |  (11) 3097-0911 | amejardins@amejardins.com.br
            </div>
        </footer><!--default footer end here-->

        <!--scripts and plugins -->
        <!--must need plugin jquery-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.min.js"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery-migrate.min.js"></script> 
        <!--bootstrap js plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>       
        <!--easing plugin for smooth scroll-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/wow.min.js" type="text/javascript"></script> 
        <!--owl carousel slider-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>        
        <!--customizable plugin edit according to your needs-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/revolution-custom.js"></script>
        <!--cube portfolio plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/cube-portfolio.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/pace.min.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/jasny/jasny-bootstrap.min.js"></script>

        
        <!--cantact form script-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jqBootstrapValidation.js" type="text/javascript"></script>
		<script>
			function processAutoheight(){
				
				$(".autoheight").each(function(){
					var maxHeight = 0;
					maxHeight = $(this).parents(".row").children(".hpadrao").outerHeight(true);
					$(this).height(maxHeight);
				})
					
			}


			$(document).ready(function() {

			$(".cep").inputmask({
				mask: '99999-999'
			});
			$(".cpf").inputmask({
				mask: '999.999.999-99'
			});
			$(".cnpj").inputmask({
				mask: '999.999.999/9999-99'
			});
			$(".tel").inputmask({
				mask: '(99) 9999-9999?9'
			});
    $(window).resize(function() { processAutoheight(); });

    $(document).resize(function() { processAutoheight(); });

    processAutoheight();
	$("#selectpss").on('change', function() {
		var valor = $(this).val();
		$(".formulario").hide();
		$("#"+valor).show();
	});
});
		</script>
  </body>
</html>