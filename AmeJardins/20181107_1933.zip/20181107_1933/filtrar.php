<?php 

require("dbcontroller.php");
$dbController = new DBController();

$bairro = $_REQUEST['bairro'];
$tema 	= $_REQUEST['tema'];
$fstatus = intval($_REQUEST['fstatus']);
$adm	= $_REQUEST['adm'];

$consulta = "where status = $fstatus ";

/*
if ($bairro == '' && $tema == '') {$consulta = ""}
if ($bairro != '' && $tema != '') {$consulta = "where bairro like '$bairro' and tema like '$tema'";}
if ($bairro != '' && $tema == '') {$consulta = "where bairro like '$bairro'";}
if ($bairro == '' && $tema != '') {$consulta = "where tema like '$tema'";}
*/
if ($tema != '') {
	$consulta = $consulta . " and tema like '$tema' ";
}
if ($bairro != '') {
	$consulta = $consulta . " and bairro like '$bairro' ";
}

include "filtrado.php";

?>
