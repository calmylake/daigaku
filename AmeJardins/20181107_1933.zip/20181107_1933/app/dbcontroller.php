<?php

class DBController {
	private $host = "ocorrenciamap.mysql.dbaas.com.br";
	private $user = "ocorrenciamap";
	private $password = "UBgIDXaIYih";
	private $database = "ocorrenciamap";
	private $conn;
	
	function __construct() {
		$this->conn = $this->connectDB();
	}
	
	function connectDB() {
		$conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
		return $conn;
	}
	
	function runQuery($query) {
		$result = mysqli_query($this->conn,$query);
		while($row=mysqli_fetch_array($result)) {
			$resultset[] = $row;
		}
		if(!empty($resultset))
			return $resultset;
	}
}
?>