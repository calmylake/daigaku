﻿Aqui consta algumas informações sobre o projeto realizado por alunos do powerlab da ESPM
Se tiver alguma dúvida, tente entrar em contato com João Pedro Libonati por whatsapp ou algo do tipo
é possível também escrever aqui e postar no servidor no diretório 'mapa', onde está o projeto Amejardins


coisas decididas

status = 0 //enviado, recebido pela associação
status = 1 //postado, colocado no mapa
status = 2 //concluído, finalizado
status = 3 //negado, descartado



lista to do:

	arrumar as <img> no site, como em: http://amejardins.com.br/mapa/caso.php?cd_ocorrencia=2
	
	pensar sobre o relatório
		quais devem ser as colunas que devem aparecer por padrão no relatório?
		como será o design do relatório?
		quais as funções que o relatório terá? (para que páginas essa página redireciona)
		data no mysql