<?php
	
	$nome   	= str_replace("'", "''", $_REQUEST['nome']);
    $associado  = str_replace("'", "''", $_REQUEST['associado']);
    $email  	= str_replace("'", "''", $_REQUEST['email']);
    $assunto 	= str_replace("'", "''", $_REQUEST['assunto']);
    $mensagem   = str_replace("'", "''", $_REQUEST['mensagem']);
    $numero   	= str_replace("'", "''", $_REQUEST['numero']);
    $rua   		= str_replace("'", "''", $_REQUEST['rua']);
    $bairro   	= str_replace("'", "''", $_REQUEST['bairro']);
    $data   	= str_replace("'", "''", $_REQUEST['data']);
    $tema   	= str_replace("'", "''", $_REQUEST['tema']);
    $latitude   = floatval($_REQUEST['latitude']);
    $longitude  = floatval($_REQUEST['longitude']);
	$senha		= "784yrehfpoui8475yfhpiu324f078234hrfuo3yq4yfgr96uher976reuoh796";
	
	$consulta = "INSERT INTO ocorrencia (nome, associado, email, assunto, mensagem, numero, rua, bairro, data, tema, latitude, longitude, senha)
	VALUES ('$nome', '$associado', '$email', '$assunto', '$mensagem', '$numero', '$rua', '$bairro', '$data', '$tema' , '$latitude', '$longitude', '$senha')";
	
	include "conexao.php";
	
	$resultado = mysqli_query($conexao, $consulta) or die ("Houve erro na gravação dos dados");
	
	$resultado = mysqli_query($conexao, "SELECT LAST_INSERT_ID();");
	$registro = mysqli_fetch_array($resultado);
	echo ('{"senha":"');
	echo ($senha);
	echo ('","id":');
	echo ($registro[0]);
	echo ('}');
	
?>