<!doctype html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0">
	
    <meta charset="utf-8">
    <title>Ame Jardins</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        margin: 0;
        padding: 0;
      }
	  body {
		  font-family :Arial;
		  text-align: center;
	  }
	  #barradenav {
		  position: relative;
		  min-height: 71px;
		  width: 100%;
		  background-color: #ecf3f8;
		  box-shadow:  0 4px 10px -2px rgba(0, 0, 0, 0.3);
		  z-index:4;
	  }
	  input {
		  background-color: transparent;
		  border-color: #000;
		  border: 1px solid;
		  border-radius: 2px;
		  -webkit-transition: background-color 200ms,color 200ms; /* For Safari 3.1 to 6.0 */
	      transition: background-color 200ms,color 200ms;
	  }
	  input:hover {
		  background-color: #000;
		  color: #fff;
		  
	  }
	  .caixa {
		  margin-top: 45px;
		  margin-left: 8px;
		  width: 95%;
		  height: 50%;
		  
	  }
	  #map-layer {
		  position:relative;
		  margin: 0 auto;
		  max-width: 100%;
		  min-height: 91vh;
		  clear:both;
		  z-index:1	;
	  }
	  
	  .container {
		  position: absolute;
			margin-top: 17px;
			display: inline-block;
			cursor: pointer;
			float: left;
		}
	#xburgi {
		position:absolute;
		  width: 280px;
		  height: 91vh;
		  visibility: hidden;
		  opacity: 0;
		  background-color:#ecf3f8;
		  float:left;
		  z-index:3	;
		  transition: 0.23s;
		  -webkit-transition: 0.23s;
          transform: translateX(-100%);
		  -webkit-transform: translateX(-100%);
	  }
	  #xburgi.appear{
		visibility: visible;
		opacity: 1;
        transform: translateX(0);
        -webkit-transform: translateX(0);
      }
	.xburgi2 {
		position:absolute;
		width: 100%;
		height: 240px;
		background-color: #fff;
		box-shadow:  0 4px 10px -2px rgba(0, 0, 0, 0.3);
	}
	#dark {
		position:absolute;
		  width: 100%;
		  height: 91vh;
		  visibility: hidden;
		  opacity: 0;
		  background-color:#000;
		  float:left;
		  z-index:2	;
		  transition: 0.23s;
		  -webkit-transition: 0.23s;
	  }
	  #dark.appear{
		visibility: visible;
		opacity: 0.5;
      }
	  .links {
		  font-size: 17px;
		  padding-top: 10px;
		  padding-left: 50px;
		  transition: 0.23s;
	  }
	  .links:hover {
		  color: #8ec8a0;
	  }
		.arrow {
			padding-left: 15px;
			padding-top: 17px;
			float:left;
			filter: brightness(0.25);
			transition: 0.23s;
		}
		.change .arrow {
			filter: brightness(1.0);
		}
		#filtrador {
			margin: 10px;
			width:84%;
			margin-top: 100px;
			padding: 2%;
			visibility: hidden;
			transition: 0.23s;
			transform: translateX(-100%);
			opacity: 0;
			z-index:2;
		}
		#filtrador.showof {
			visibility: visible;
			opacity:1;
			transform: translateX(0);
			
		}
		.formisso select{
			radius: 300px;
	  }
	  .formisso p{
		  margin: 0;
	  }
	  .formisso select,form input {
		  margin-top: 2px;
		  width:80%;
		  float: right;
		  font-size: 15px;
	  }	
    </style>
	 <!-- Bootstrap -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- font awesome for icons -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/animate.css" rel="stylesheet" type="text/css" media="screen"> 
        <!-- Revolution Style-sheet -->
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/css/settings.css">
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/css/rev-style.css">
        <!--owl carousel css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/yamm.css" rel="stylesheet" type="text/css">
        <!--cube css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css">
        <!-- custom css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/style.css?v=1" rel="stylesheet" type="text/css" media="screen">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
  </head>
  <body class="page-template page-template-fazemos page-template-fazemos-php page page-id-67 group-blog">
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78743991-3', 'auto');
ga('send', 'pageview');

</script>
<div id="barradenav">
	<a href="#" onclick="window.history.go(-1)"><img src="http://amejardins.com.br/mapa/app/icons/arrow3.png" class="arrow" ></a>
	<img src="http://amejardins.com.br/wp-content/themes/ametema/img/logo.png" alt="Ame Jardins" style="margin: 15px; float:right;">
</div>
<style>
.tjust p{
	text-align:justify;
	padding-right:20px
}
#rodape {
		clear:both;
		min-height: 500px;
		width: 90%;
		margin: 0 auto;
	}
@media(min-width:700px) {
	#rodape {
		clear:both;
		min-height: 500px;
		width: 60%;
		margin: 0 auto;
	}
}
</style>
<div id="rodape" style="">
<?php 

include "conexao.php";

$cd_ocorrencia = $_REQUEST['cd_ocorrencia'];


if(file_exists('../uploads/'.$cd_ocorrencia.'.jpg')) {
	$imagem =  '../uploads/'.$cd_ocorrencia.'.jpg';
}
else {
	$imagem = '../uploads/_noimg.jpg';
}

$consulta = 
	"select
	email, assunto, mensagem, rua, numero, bairro, tema, data, status, view
	from ocorrencia 
    where  cd_ocorrencia = $cd_ocorrencia";




$resultado = mysqli_query($conexao, $consulta) or die ("Não foi possível realizar a consulta ao banco de dados");

// Agora iremos "obter" cada campo da notícia e organizar no HTML 
echo "<div id='content3'>";

while ($linha=mysqli_fetch_array($resultado)) {

$email 		= $linha['email'];
$assunto	= $linha['assunto'];
$mensagem	= $linha['mensagem'];
$rua		= $linha['rua'];
$numero		= $linha['numero'];
$bairro  	= $linha['bairro'];
$tema 		= $linha['tema'];
$data		= $linha['data'];
$status		= $linha['status'];
$view		= $linha['view'];


switch ($bairro) {
	case "jardim_america":
		$bairro = "Jardim América";
		break;
	case "jardim_europa":
		$bairro = "Jardim Europa";
		break;
	case "jardim_paulista":
		$bairro = "Jardim Paulista";
		break;
	case "jardim_paulistano":
		$bairro = "Jardim Paulistano";
}


echo "	
<br>
<p style='font-size:2em; font-weight: bold;'>$assunto</p>
<div id= 'fotoocorrencia' style='width: 300px;height: 300px;margin: 0 auto;background: url($imagem);background-size: contain; background-repeat: no-repeat; background-position: center;'></div>
<div id='ocorrencia' style='max-width: 780px;'>
				
				
				<div id= 'statusocorrencia' style=''>
					<p></p>
					<p>$mensagem</p>
					<p>Local: $rua, $numero - $bairro<br>
					   Data: ".date('d/m/Y', $data)."<br>
					   Visualizações: $view</p>
				</div>
		</div>";

}




	$update = "UPDATE ocorrencia SET view = view + 1 WHERE cd_ocorrencia=$cd_ocorrencia"; 
	$resultado_update = mysqli_query($conexao, $update) or die ("Houve erro no UPDATE!");

?></div>
</div>
        <!--scripts and plugins -->
        <!--must need plugin jquery-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.min.js"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery-migrate.min.js"></script> 
        <!--bootstrap js plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>       
        <!--easing plugin for smooth scroll-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/wow.min.js" type="text/javascript"></script> 
        <!--owl carousel slider-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>        
        <!--customizable plugin edit according to your needs-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/revolution-custom.js"></script>
        <!--cube portfolio plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/cube-portfolio.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/pace.min.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/jasny/jasny-bootstrap.min.js"></script>

        
        <!--cantact form script-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jqBootstrapValidation.js" type="text/javascript"></script>
		<script>
			function processAutoheight(){
				
				$(".autoheight").each(function(){
					var maxHeight = 0;
					maxHeight = $(this).parents(".row").children(".hpadrao").outerHeight(true);
					$(this).height(maxHeight);
				})
					
			}


			$(document).ready(function() {

			$(".cep").inputmask({
				mask: '99999-999'
			});
			$(".cpf").inputmask({
				mask: '999.999.999-99'
			});
			$(".cnpj").inputmask({
				mask: '999.999.999/9999-99'
			});
			$(".tel").inputmask({
				mask: '(99) 9999-9999?9'
			});
    $(window).resize(function() { processAutoheight(); });

    $(document).resize(function() { processAutoheight(); });

    processAutoheight();
	$("#selectpss").on('change', function() {
		var valor = $(this).val();
		$(".formulario").hide();
		$("#"+valor).show();
	});
});
		</script>
  </body>
</html>