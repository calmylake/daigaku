<?php

include "checaLogin.php";
if (!checaLogin()) {
	header('Location: login.php', true, 302);
	exit();
}

?>
