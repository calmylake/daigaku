<?php
	$conexao = mysqli_connect("ocorrenciamap.mysql.dbaas.com.br","ocorrenciamap","UBgIDXaIYih","ocorrenciamap") or die ("A conexão não foi executada com sucesso");
	
?>
