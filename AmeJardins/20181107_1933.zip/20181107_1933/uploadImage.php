<?php
	
	define("SERVER", "ocorrenciamap.mysql.dbaas.com.br");
	define("USER", "ocorrenciamap");
	define("PASSWORD", "UBgIDXaIYih");
	define("DB", "ocorrenciamap");
	
	$mysql = new mysqli(SERVER,USER,PASSWORD,DB);
	
	$response = array();
	if($mysql->connect_error) {
		$response["MESSAGE"] = "ERROR IN SERVER";
		$response["STATUS"] = 500;
		
	}
	else {
		if(is_uploaded_file($_FILES["user_image"]["tmp_name"])) {
			
			$tmp_file = $_FILES["user_image"]["tmp_name"];
			$img_name = $_FILES["user_image"]["name"];
			$upload_dir = "./uploads/" .$img_name;
			
			
			if(move_uploaded_file($tmp_file,$upload_dir)){
				
				$response["MESSAGE"] = "UPLOAD SUCCESS!";
				$response["STATUS"] = 200;
			}
			else {
				$response["MESSAGE"] = "UPLOAD FAILED!";
				$response["STATUS"] = 404;
				
			}
		}
		else {
			$response["MESSAGE"] = "INVALID REQUEST";
			$response["STATUS"] = 400;
			
		}
	
	}
	
	echo json_encode($response);
?>