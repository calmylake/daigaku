<script type="text/javascript">
	
	var map;
	var geocoder;		
	var marker;
		
      function initMap() {
		
		
		  
		var mapLayer = document.getElementById("map-layer");
		var centerCoordinates = new google.maps.LatLng(-23.5730000,-46.6737500);
		var defaultOptions = { center: centerCoordinates, zoom: 15 };
		
		map = new google.maps.Map(mapLayer, defaultOptions);
		geocoder = new google.maps.Geocoder();
		
		/*var icons = {
          arvore: {
            icon: 'markers/arvore.png'
          },
          buraco: {
            icon: 'markers/buraco.png'
          },
          iluminacao: {
            icon: 'markers/iluminacao.png'
          }
		  obra: {
            icon: 'markers/obra.png'
          }
		  sinalizacao: {
            icon: 'markers/sinalizacao.png'
          }
        };*/
		
		
		<?php 
            if(!empty($endereco)) {

                foreach($endereco as $k=>$v) {
					
					if(file_exists('../uploads/'.$endereco[$k]["cd_ocorrencia"].'.jpg') )$imagem =  '../uploads/'.$endereco[$k]["cd_ocorrencia"].'.jpg' ;
					else $imagem = '../uploads/_noimg.jpg';
        ?>  
					geocoder.geocode( { 'address': '<?php echo 'brasil, sp, são paulo '.$endereco[$k]["bairro"].' '. $endereco[$k]["rua"].' '. $endereco[$k]["numero"]  ; ?>' }, function(LocationResult, status) {
						
					
					
							//var latitude = LocationResult[0].geometry.location.lat();
							//var longitude = LocationResult[0].geometry.location.lng();
					
							var latitude = <?php echo $endereco[$k]["latitude"]; ?>;
							var longitude = <?php echo $endereco[$k]["longitude"]; ?>;
					
				
					
					
						
							<?php $contador = $contador + 1; ?>
						
							if (<?php echo $endereco[$k]["status"] ?> == 0){
								google.maps.event.addDomListener(window, 'load', function() {
								
									var icon = {
										url: '../markers/<?php
									
											switch ($endereco[$k]["tema"]) {
												case "acessibilidade":
													echo "roxo";
													break;
												case "areas_verdes":
													echo "verde";
													break;
												case "seguranca_publica":
													echo "amarelo";
													break;
												case "transito":
													echo "vermelho";
													break;
												case "uso_irregular_do_solo":
													echo "azul";
													break;
												case "zeladoria_urbana":
													echo "laranja";
													break;
												case "outros":
													echo "preto";
													break;
											}
									
										?>.png', // url
										scaledSize: new google.maps.Size(50, 50), // scaled size
										origin: new google.maps.Point(0,0), // origin
										anchor: new google.maps.Point(25, 50) // anchor
									};
								
									marker = new google.maps.Marker({
										position: new google.maps.LatLng(latitude, longitude),
										map: map,
										title: '<?php
										
											switch ($endereco[$k]["bairro"]) {
														case "jardim_america":
															echo "Jardim América";
															break;
														case "jardim_europa":
															echo "Jardim Europa";
															break;
														case "jardim_paulista":
															echo "Jardim Paulista";
															break;
														case "jardim_paulistano":
															echo "Jardim Paulistano";
											}
											echo ', '.$endereco[$k]["rua"].', '.$endereco[$k]["numero"]; ?>',
										icon: icon
									});
									
									
									var contentString = '<div id="<?php echo $endereco[$k]["cd_ocorrencia"]?>" style="min-height: 100px; min-width: 100px;" id=container> <a href="caso.php?cd_ocorrencia=<?php echo $endereco[$k]["cd_ocorrencia"]?>"><img src="<?php echo $imagem; ?>" height="200" width="200"></img><br><?php 
									
									
									echo $endereco[$k]["assunto"].'<br>';
									
									switch ($endereco[$k]["bairro"]) {
										case "jardim_america":
											echo "Jardim América";
											break;
										case "jardim_europa":
											echo "Jardim Europa";
											break;
										case "jardim_paulista":
											echo "Jardim Paulista";
											break;
										case "jardim_paulistano":
											echo "Jardim Paulistano";
									}
									
									$data = date("d/m/Y", strtotime($endereco[$k]["data"]));
								
									echo ', '.$endereco[$k]["rua"].', '.$endereco[$k]["numero"].'<br>'.$data.'<br>';
									
									switch ($endereco[$k]["tema"]) {
										case "acessibilidade":
											echo "Acessibilidade";
											break;
										case "areas_verdes":
											echo "Áreas Verdes";
											break;
										case "seguranca_publica":
											echo "Seguranca Pública";
											break;
										case "transito":
											echo "Trânsito";
											break;
										case "uso_irregular_do_solo":
											echo "Uso Irregular do Solo";
											break;
										case "zeladoria_urbana":
											echo "Zeladoria Urbana";
											break;
										case "outros":
											echo "Outros";
											break;
									}
									
									?></a></div>';
									var infowindow = new google.maps.InfoWindow({
										content: contentString
									});
									
									google.maps.event.addListener(marker, 'click', function() {
										infowindow.close();
										infowindow.open(map, this);
									});
								});
							}
							
							if (<?php echo $endereco[$k]["status"] ?> == 1) {
							
								google.maps.event.addDomListener(window, 'load', function() {
								
								if (<?php echo $endereco[$k]["status"]?> == 1){
									var icon = {
										url: '../markers/<?php
									
											switch ($endereco[$k]["tema"]) {
												case "acessibilidade":
													echo "adm_roxo";
													break;
												case "areas_verdes":
													echo "adm_verde";
													break;
												case "seguranca_publica":
													echo "adm_amarelo";
													break;
												case "transito":
													echo "adm_vermelho";
													break;
												case "uso_irregular_do_solo":
													echo "adm_azul";
													break;
												case "zeladoria_urbana":
													echo "adm_laranja";
													break;
												case "outros":
													echo "adm_preto";
													break;
											}
									
										?>.png', // url
										scaledSize: new google.maps.Size(50, 50), // scaled size
										origin: new google.maps.Point(0,0), // origin
										anchor: new google.maps.Point(25, 50) // anchor
									};
								} else {
									var icon = {
											url: '../markers/<?php
										
												switch ($endereco[$k]["tema"]) {
													case "acessibilidade":
														echo "roxo";
														break;
													case "areas_verdes":
														echo "verde";
														break;
													case "seguranca_publica":
														echo "amarelo";
														break;
													case "transito":
														echo "vermelho";
														break;
													case "uso_irregular_do_solo":
														echo "azul";
														break;
													case "zeladoria_urbana":
														echo "laranja";
														break;
													case "outros":
														echo "preto";
														break;
												}
										
											?>.png', // url
											scaledSize: new google.maps.Size(50, 50), // scaled size
											origin: new google.maps.Point(0,0), // origin
											anchor: new google.maps.Point(25, 50) // anchor
										};
								}
								
									marker = new google.maps.Marker({
									position: new google.maps.LatLng(latitude, longitude),
									map: map,
									title: '<?php
									
									switch ($endereco[$k]["bairro"]) {
												case "jardim_america":
													echo "Jardim América";
													break;
												case "jardim_europa":
													echo "Jardim Europa";
													break;
												case "jardim_paulista":
													echo "Jardim Paulista";
													break;
												case "jardim_paulistano":
													echo "Jardim Paulistano";
									}
									echo ', '.$endereco[$k]["rua"].', '.$endereco[$k]["numero"]; ?>',
									icon: icon
									});
									
									
									var contentString = '<div id="<?php echo $endereco[$k]["cd_ocorrencia"]?>" style="min-height: 100px; min-width: 100px;" id=container> <a href="caso.php?cd_ocorrencia=<?php echo $endereco[$k]["cd_ocorrencia"]?>"><img src="<?php echo $imagem; ?>" height="200" width="200"></img><br><?php 
									
									
									echo $endereco[$k]["assunto"].'<br>';
									
									
									switch ($endereco[$k]["bairro"]) {
												case "jardim_america":
													echo "Jardim América";
													break;
												case "jardim_europa":
													echo "Jardim Europa";
													break;
												case "jardim_paulista":
													echo "Jardim Paulista";
													break;
												case "jardim_paulistano":
													echo "Jardim Paulistano";
									}
									
									$data = date("d/m/Y", strtotime($endereco[$k]["data"]));
									
									echo ', '.$endereco[$k]["rua"].', '.$endereco[$k]["numero"].'<br>'.$data.'<br>';
									
									switch ($endereco[$k]["tema"]) {
												case "acessibilidade":
													echo "Acessibilidade";
													break;
												case "areas_verdes":
													echo "Áreas Verdes";
													break;
												case "seguranca_publica":
													echo "Seguranca Pública";
													break;
												case "transito":
													echo "Trânsito";
													break;
												case "uso_irregular_do_solo":
													echo "Uso Irregular do Solo";
													break;
												case "zeladoria_urbana":
													echo "Zeladoria Urbana";
													break;
												case "outros":
													echo "Outros";
													break;
								}
								
								?></a></div>';
								var infowindow = new google.maps.InfoWindow({
									content: contentString
								});
								
								   google.maps.event.addListener(marker, 'click', function() {
										infowindow.open(map, this);
									});
								});
						
						}
						
						
						
						//else alert("Geocode failed, status="+status);
				
					});
			
	    <?php
                }
				//echo $contador;
            }
	    ?>
		  var trafficLayer = new google.maps.TrafficLayer();
          trafficLayer.setMap(map);
		  
      }
    </script>
    <script async defer
		src="https://maps.googleapis.com/maps/api/js?key=<?php echo AIzaSyA6ysBoiWNEiQKRzPgymJroG_j_U2xPnnM; ?>&callback=initMap">
    </script>