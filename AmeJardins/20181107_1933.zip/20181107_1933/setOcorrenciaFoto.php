<?php
	/*
	id query string
	converte para int
	
	vai no banco e confirma que o cd_ocorrencia existe
	WHERE cd_ocorrencia = id AND senha = password
	*/
	
	$id = intval($_REQUEST['id']);
	$senha = str_replace("'", "''", $_REQUEST['senha']);
	$nomeDoArquivo = 'uploads/'.$id.'.jpg';
	$codigoRetorno = "0";
	try{
		$consulta = "SELECT cd_ocorrencia FROM ocorrencia WHERE cd_ocorrencia=$id AND senha='$senha'";
		include "conexao.php";
		$resultado = mysqli_query($conexao, $consulta);
		$registro = mysqli_fetch_array($resultado);
		if($registro[0] == $id){
			file_put_contents($nomeDoArquivo, file_get_contents("php://input"));
			$consulta = "UPDATE ocorrencia SET senha = NULL WHERE cd_ocorrencia=$id";
			$resultado = mysqli_query($conexao, $consulta);
			$codigoRetorno = "1";
		}
	}catch(Exception $e){
	}
	echo $codigoRetorno;
	
	
	
	/*
	
	
	$str = $_REQUEST('strFoto');
	//str = "nomeDaFoto.txt"
	file_put_contents(str, file_get_contents("amejardins.com.br/mapa/getOcorrenciaFoto.php"));
	
	
	
	
	$resultado = mysqli_query($conexao, $consulta) or die ("<br>2Houve erro na gravação dos dados, por favor, clique em voltar e verifique os campos obrigatórios!");
	 list($cod_ocorrencia) = mysqli_fetch_row($resultado);
	$target_dir = "uploads/";
	$target_file = $target_dir . $cod_ocorrencia . '.jpg';
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	// Check if image file is a actual image or fake image
	if(isset($_POST["botao"])) {
		$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
		if($check !== false) {
			//echo "File is an image - " . $check["mime"] . ".";
			$uploadOk = 1;
		} else {
			echo "O arquivo não é uma imagem.";
			$uploadOk = 0;
		}
	}
	// Check if file already exists
	if (file_exists($target_file)) {
		echo "Erro,o arquivo já existe.";
		$uploadOk = 0;
	}
	// Check file size
	if ($_FILES["fileToUpload"]["size"] > 50000000) {
		echo "Erro, arquivo com tamanho muito grande.";
		$uploadOk = 0;
	}
	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" ) {
		echo "ERRO, somente estes formatos de arquivos são permitidos: JPG, JPEG, PNG e GIF.";
		$uploadOk = 0;
	}
	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
		echo "Seu arquivo não foi enviado.";
	// if everything is ok, try to upload file
	} else {
		if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			//echo "O arquivo  ". basename( $_FILES["fileToUpload"]["name"]). " foi enviado.";
		} else {
			echo "Erro de envio do arquivo de imagem: ".basename( $_FILES["fileToUpload"]["name"]);
		}
	}
	  
	  
	echo "<h1 align='center'>Cadastro efetuado com tentativa!</h1><br><a href='index.php' align='center' style='text-decoration: none'><p style='font-size: 25px;'>VOLTAR</p></a>";
	
	*/
	
?>