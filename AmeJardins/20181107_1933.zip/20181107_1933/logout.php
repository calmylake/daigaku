<?php
$cookie = $_COOKIE["usuario"];
if ($cookie && strlen($cookie) == 58) {
	include "conexao.php";
	
	$id = hexdec(substr($cookie, 0, 8));
	$token = str_replace("'", "''", substr($cookie, 8));
	
	mysqli_query($conexao, "UPDATE usuario SET token = null WHERE id = $id AND token = '$token'") or die ("Não foi possível realizar a consulta ao banco de dados");
}
setcookie("usuario", "", time() - (86400 * 365), "/");
header('Location: login.php', true, 302);
exit();
?>
<!DOCTYPE html>
<html>
  <head>
  </head>
  <body>
  </body>
</html>
