
<?php
define("API_KEY","AIzaSyA6ysBoiWNEiQKRzPgymJroG_j_U2xPnnM");
$where = '';
$query = "SELECT * FROM ocorrencia " . $consulta;
$endereco = $dbController->runQuery($query);
?>
<html style="hight: 100%">
  <head>
    <meta name="viewport" content="initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <title>Ame Jardins</title>
    <style>
      #map {
      }		
      /* Optional: Makes the sample page fill the window. */
      html, body {
        margin: 0;
        padding: 0;
      }
	  body {
		-webkit-font-smoothing: antialiased;
		-webkit-text-size-adjust: 100%;
		-ms-text-size-adjust: 100%;
		color: #424242;
		font-weight: 300;
		font-size: 12px;
		line-height: 24px;
		background-color: #fff;
		font-family: "Montserrat", sans-serif;
		height: 100%;
	  }
	   #barradenav {
		  position: relative;
		  min-height: 71px;
		  width: 100%;
		  background-color: #ecf3f8;
		  box-shadow:  0 4px 10px -2px rgba(0, 0, 0, 0.3);
		  z-index:7;
	  }
	  input {
		  background-color: transparent;
		  border-color: #000;
		  border: 1px solid;
		  border-radius: 2px;
		  -webkit-transition: background-color 200ms,color 200ms; /* For Safari 3.1 to 6.0 */
	      transition: background-color 200ms,color 200ms;
	  }
	  input:hover {
		  background-color: #000;
		  color: #fff;
		  
	  }
	  .caixa {
		  margin-top: 45px;
		  margin-left: 8px;
		  width: 95%;
		  height: 50%;
		  
	  }
	  #map-layer {
		position: absolute;
		margin: 0;
		padding: 0;
		clear: both;
		z-index: 1;
		bottom: 0;
		top: 71px;
		left: 0;
		right: 0;
	  }
	  
	  .container {
		  position: absolute;
			margin-top: 17px;
			display: inline-block;
			cursor: pointer;
			float: left;
		}
	#xburgi {
		position: absolute;
		width: 280px;
		visibility: hidden;
		opacity: 0;
		background-color: #ecf3f8;
		float: left;
		z-index: 4;
		transition: 0.23s;
		-webkit-transition: 0.23s;
		transform: translateX(-100%);
		-webkit-transform: translateX(-100%);
		top: 71px;
		bottom: 0;
		box-shadow:  0 4px 10px -2px rgba(0, 0, 0, 0.9 	);
}
	  #xburgi.appear{
		visibility: visible;
		opacity: 1;
        transform: translateX(0);
        -webkit-transform: translateX(0);
      }
	.xburgi2 {
		position:absolute;
		width: 100%;
		height: 240px;
		background-color: #fff;
		box-shadow:  0 4px 10px -2px rgba(0, 0, 0, 0.3);
	}
	#dark {
		position: absolute;
		visibility: hidden;
		opacity: 0;
		background-color: #000;
		float: left;
		z-index: 3;
		transition: 0.23s;
		-webkit-transition: 0.23s;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
	}

	  #dark.appear{
		visibility: visible;
		opacity: 0.5;
      }
	  #bolinha {
		 position: fixed;
		 z-index: 2;
		 bottom: 3.2vh;
		 left: 3.2vh;
		 border-radius: 40vh;
		 box-shadow:  0 4px 10px -2px rgba(0, 0, 0, 0.3);
	  }
	  #botaohan {
		width: 10vh;
		height: 10vh;
		border-radius: 40vh;
		border: 0;
		background-color: #333;
		color: #fff;
		font-size:30px;
	  }
	  .links {
		  font-size: 17px;
		  padding-top: 10px;
		  padding-left: 50px;
		  transition: 0.23s;
	  }
	  .links:hover {
		  color: #8ec8a0;
	  }
		.bar1, .bar2, .bar3 {
			width: 35px;
			height: 3px;
			background-color: #333;
			margin: 6px 0;
			transition: 0.23s;
			border-radius: 200px;
		}
		.change .bar1 {
			background-color: #8ec8a0;	
		}

		.change .bar2 {background-color: #8ec8a0;}

		.change .bar3 {
			background-color: #8ec8a0;
		}
		#filtrador {
			margin: 10px;
			width:84%;
			margin-top: 100px;
			padding: 2%;
			visibility: hidden;
			transition: 0.23s;
			transform: translateX(-100%);
			opacity: 0;
			z-index:2;
		}
		#filtrador.showof {
			visibility: visible;
			opacity:1;
			transform: translateX(0);
			
		}
		.formisso select{
			radius: 300px;
	  }
	  .formisso p{
		  margin: 0;
	  }
	  .formisso select,form input {
		  margin-top: 2px;
		  width:80%;
		  float: right;
		  font-size: 15px;
	  }
    </style>
	 <!-- Bootstrap -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- font awesome for icons -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/animate.css" rel="stylesheet" type="text/css" media="screen"> 
        <!-- Revolution Style-sheet -->
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/css/settings.css">
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/css/rev-style.css">
        <!--owl carousel css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/yamm.css" rel="stylesheet" type="text/css">
        <!--cube css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css">
        <!-- custom css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/style.css?v=1" rel="stylesheet" type="text/css" media="screen">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
  </head>
  <body class="page-template page-template-fazemos page-template-fazemos-php page page-id-67 group-blog">
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78743991-3', 'auto');
ga('send', 'pageview');

</script>
<style>
.tjust p{
	text-align:justify;
	padding-right:20px
}
</style>
<div id="barradenav">
<div class="container" onclick="setVisibility(this);" id='toggle'>
  <div class="bar1"></div>
  <div class="bar2"></div>
  <div class="bar3"></div>
</div>
<img src="http://amejardins.com.br/wp-content/themes/ametema/img/logo.png" alt="Ame Jardins" style="margin: 15px; float:right;">
</div>
<div id="xburgi">
	<div class="xburgi2">
		<div class="caixa">
			<a href="http://amejardins.com.br/mapa/app"><img src="http://amejardins.com.br/mapa/app/icons/map1.png" alt="Ame Jardins" style="float:left;"><p class="links">Mapa</p></a>
			<a href="http://amejardins.com.br/mapa/app/criar.php"><img src="http://amejardins.com.br/mapa/app/icons/register1.png" alt="Ame Jardins" style="float:left; padding-top:7px; padding-left: 7px"><p class="links">Registro de Ocorrência</p></a>
			<a href="#" id="ativarfiltro"><img src="http://amejardins.com.br/mapa/app/icons/filter1.png" alt="Ame Jardins" style="float:left; padding-top:7px; padding-left: 7px"><p class="links">Filtrar</p></a>
		</div>
		<div id="filtrador" class="filtro" >
			<form class="formisso" action="filtrar.php" method="post">
				<p>
					<label style="font-size:20px;">Filtrar por:</label><br><br>
					<label>Bairro</label>
					<select name="bairro" class="filtrarr">
						<option selected value>Todos</option>
						<option value="jardim_america">Jardim América</option>
						<option value="jardim_europa">Jardim Europa</option>
						<option value="jardim_paulista">Jardim Paulista</option>
						<option value="jardim_paulistano">Jardim Paulistano</option>
					</select>
				</p>
				<p>
				<label>Tema</label>
					<select name="tema" style="min-height: 20px;">
						<option selected value>Todos</option>
						<option value="acessibilidade">Acessibilidade</option>
						<option value="areas_verdes">Áreas Verdes</option>
						<option value="seguranca_publica">Segurança Pública</option>
						<option value="transito">Trânsito</option>
						<option value="uso_irregular_do_solo">Uso Irregular do Solo</option>
						<option value="zeladoria_urbana">Zeladoria Urbana</option>
						<option value="outros">Outros</option>
					</select>
				</p><br>
				<p class="total">
					<input class="filtrarr" type="submit" value="Filtrar" style="width: 100%; height: 40px;">
				</p>
				</form>
			
		</div>
	</div>
</div>
<div id="dark" onclick="setVisibility(toggle);"></div>
    <div id="map-layer"></div>
	<div id="bolinha" >
		<button type="button" id = "botaohan" onclick="location.href='http://amejardins.com.br/mapa/app/criar.php'">!</button>
	</div>
	
	
    <!--<div id="map" style="background: #F00"></div>-->
	
    <?php include "scriptmapa.php"; ?>
    
	<!--<script async defer
		src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA6ysBoiWNEiQKRzPgymJroG_j_U2xPnnM&callback=initMap">
    </script>-->
	
        <!--scripts and plugins -->
        <!--must need plugin jquery-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.min.js"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery-migrate.min.js"></script> 
        <!--bootstrap js plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>       
        <!--easing plugin for smooth scroll-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/wow.min.js" type="text/javascript"></script> 
        <!--owl carousel slider-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>        
        <!--customizable plugin edit according to your needs-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/revolution-custom.js"></script>
        <!--cube portfolio plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/cube-portfolio.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/pace.min.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/jasny/jasny-bootstrap.min.js"></script>

        
        <!--cantact form script-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jqBootstrapValidation.js" type="text/javascript"></script>
		<script>
			function processAutoheight(){
				
				$(".autoheight").each(function(){
					var maxHeight = 0;
					maxHeight = $(this).parents(".row").children(".hpadrao").outerHeight(true);
					$(this).height(maxHeight);
				})
					
			}


			$(document).ready(function() {

			$(".cep").inputmask({
				mask: '99999-999'
			});
			$(".cpf").inputmask({
				mask: '999.999.999-99'
			});
			$(".cnpj").inputmask({
				mask: '999.999.999/9999-99'
			});
			$(".tel").inputmask({
				mask: '(99) 9999-9999?9'
			});
    $(window).resize(function() { processAutoheight(); });

    $(document).resize(function() { processAutoheight(); });

    processAutoheight();
	$("#selectpss").on('change', function() {
		var valor = $(this).val();
		$(".formulario").hide();
		$("#"+valor).show();
	});
});
function setVisibility(x) {
	x.classList.toggle("change");
}
var toggle  = document.getElementById("toggle");
var content = document.getElementById("xburgi");
var content2 = document.getElementById("dark");
toggle.addEventListener("click", function(){
  content.classList.toggle("appear");
  content2.classList.toggle("appear");
}, false);
var toggle2 = document.getElementById("ativarfiltro");
  var content3 = document.getElementById("filtrador");
  toggle2.addEventListener("click", function(){
  content3.classList.toggle("showof");
}, false);
var toggle3  = document.getElementById("dark");
toggle3.addEventListener("click", function(){
	content.classList.toggle("appear");
	content2.classList.toggle("appear");
}, false);
		</script>
  </body>
</html>
