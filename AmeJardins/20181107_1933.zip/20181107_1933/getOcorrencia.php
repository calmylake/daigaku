<?php
$id = intval($_REQUEST['id']);$bairro = ($_REQUEST['bairro']);$tema = ($_REQUEST['tema']);
require("dbcontroller.php");
$dbController = new DBController();
if($bairro != "" && $tema != ""){		$query = "SELECT * FROM ocorrencia WHERE bairro=$bairro and tema=$tema and status=1";		$endereco = $dbController->runQuery($query);		if(!empty($endereco)){		echo '[';		$primeiraVez = 1;		foreach($endereco as $k=>$v) {			if ($primeiraVez == 0) {				echo ",";			} else {				$primeiraVez = 0;			}			echo "{";			echo '"cd_ocorrencia":';			echo json_encode($endereco[$k]["cd_ocorrencia"]);			echo ',"assunto":';			echo json_encode($endereco[$k]["assunto"]);			echo ',"numero":';			echo json_encode($endereco[$k]["numero"]);			echo ',"rua":';			echo json_encode($endereco[$k]["rua"]);			echo ',"bairro":';			echo json_encode($endereco[$k]["bairro"]);			echo ',"data":';			echo json_encode($endereco[$k]["data"]);			echo ',"tema":';			echo json_encode($endereco[$k]["tema"]);			echo ',"status":';			echo json_encode($endereco[$k]["status"]);			echo ',"longitude":';			echo json_encode($endereco[$k]["longitude"]);			echo ',"latitude":';			echo json_encode($endereco[$k]["latitude"]);			echo "}";		}	echo "]";	}else{		echo "0";	}	}elseif($tema != ""){		$query = "SELECT * FROM ocorrencia WHERE tema=$tema and status=1";		$endereco = $dbController->runQuery($query);		if(!empty($endereco)){		echo '[';		$primeiraVez = 1;		foreach($endereco as $k=>$v) {			if ($primeiraVez == 0) {				echo ",";			} else {				$primeiraVez = 0;			}			echo "{";			echo '"cd_ocorrencia":';			echo json_encode($endereco[$k]["cd_ocorrencia"]);			echo ',"assunto":';			echo json_encode($endereco[$k]["assunto"]);			echo ',"numero":';			echo json_encode($endereco[$k]["numero"]);			echo ',"rua":';			echo json_encode($endereco[$k]["rua"]);			echo ',"bairro":';			echo json_encode($endereco[$k]["bairro"]);			echo ',"data":';			echo json_encode($endereco[$k]["data"]);			echo ',"tema":';			echo json_encode($endereco[$k]["tema"]);			echo ',"status":';			echo json_encode($endereco[$k]["status"]);			echo ',"longitude":';			echo json_encode($endereco[$k]["longitude"]);			echo ',"latitude":';			echo json_encode($endereco[$k]["latitude"]);			echo "}";		}	echo "]";	}else{		echo "0";	}	}elseif($bairro != ""){		$query = "SELECT * FROM ocorrencia WHERE bairro=$bairro and status=1";		$endereco = $dbController->runQuery($query);		if(!empty($endereco)){		echo '[';		$primeiraVez = 1;		foreach($endereco as $k=>$v) {			if ($primeiraVez == 0) {				echo ",";			} else {				$primeiraVez = 0;			}			echo "{";			echo '"cd_ocorrencia":';			echo json_encode($endereco[$k]["cd_ocorrencia"]);			echo ',"assunto":';			echo json_encode($endereco[$k]["assunto"]);			echo ',"numero":';			echo json_encode($endereco[$k]["numero"]);			echo ',"rua":';			echo json_encode($endereco[$k]["rua"]);			echo ',"bairro":';			echo json_encode($endereco[$k]["bairro"]);			echo ',"data":';			echo json_encode($endereco[$k]["data"]);			echo ',"tema":';			echo json_encode($endereco[$k]["tema"]);			echo ',"status":';			echo json_encode($endereco[$k]["status"]);			echo ',"longitude":';			echo json_encode($endereco[$k]["longitude"]);			echo ',"latitude":';			echo json_encode($endereco[$k]["latitude"]);			echo "}";		}	echo "]";	}else{		echo "0";	}	}
elseif($id != ""){
		
	$query = "SELECT * FROM ocorrencia WHERE cd_ocorrencia=$id and status=1";
	$endereco = $dbController->runQuery($query);
	$k = 0;
	
	if(!empty($endereco)){
		echo "{";
		echo '"cd_ocorrencia":';
		echo json_encode($endereco[$k]["cd_ocorrencia"]);
		echo ',"nome":';
		echo json_encode($endereco[$k]["nome"]);
		echo ',"assunto":';
		echo json_encode($endereco[$k]["assunto"]);
		echo ',"mensagem":';
		echo json_encode($endereco[$k]["mensagem"]);
		echo ',"numero":';
		echo json_encode($endereco[$k]["numero"]);
		echo ',"rua":';
		echo json_encode($endereco[$k]["rua"]);
		echo ',"bairro":';
		echo json_encode($endereco[$k]["bairro"]);
		echo ',"data":';
		echo json_encode($endereco[$k]["data"]);
		echo ',"tema":';
		echo json_encode($endereco[$k]["tema"]);
		echo ',"status":';
		echo json_encode($endereco[$k]["status"]);
		echo ',"view":';
		echo json_encode($endereco[$k]["view"]);
		echo ',"longitude":';
		echo json_encode($endereco[$k]["longitude"]);
		echo ',"latitude":';
		echo json_encode($endereco[$k]["latitude"]);
		echo "}";
	}
	else{
		echo "0";
	}
}
else {
	
	$query = "SELECT * FROM ocorrencia WHERE status=1";
	$endereco = $dbController->runQuery($query);
	
	if(!empty($endereco)){
		echo '[';
		$primeiraVez = 1;
		foreach($endereco as $k=>$v) {
			if ($primeiraVez == 0) {
				echo ",";
			} else {
				$primeiraVez = 0;
			}
			echo "{";
			echo '"cd_ocorrencia":';
			echo json_encode($endereco[$k]["cd_ocorrencia"]);
			echo ',"assunto":';
			echo json_encode($endereco[$k]["assunto"]);
			echo ',"numero":';
			echo json_encode($endereco[$k]["numero"]);
			echo ',"rua":';
			echo json_encode($endereco[$k]["rua"]);
			echo ',"bairro":';
			echo json_encode($endereco[$k]["bairro"]);
			echo ',"data":';
			echo json_encode($endereco[$k]["data"]);
			echo ',"tema":';
			echo json_encode($endereco[$k]["tema"]);
			echo ',"status":';
			echo json_encode($endereco[$k]["status"]);
			echo ',"longitude":';
			echo json_encode($endereco[$k]["longitude"]);
			echo ',"latitude":';
			echo json_encode($endereco[$k]["latitude"]);
			echo "}";
		}
	echo "]";
	}else{
		echo "0";
	}
}






/*
			echo json_encode($endereco[$k]["cd_ocorrencia"]);
			echo json_encode($endereco[$k]["nome"]);
			echo json_encode($endereco[$k]["associado"]);
			echo json_encode($endereco[$k]["email"]);
			echo json_encode($endereco[$k]["assunto"]);
			echo json_encode($endereco[$k]["mensagem"]);
			echo json_encode($endereco[$k]["numero"]);
			echo json_encode($endereco[$k]["rua"]);
			echo json_encode($endereco[$k]["bairro"]);
			echo json_encode($endereco[$k]["data"]);
			echo json_encode($endereco[$k]["tema"]);
			echo json_encode($endereco[$k]["foto"]);
			echo json_encode($endereco[$k]["status"]);
			echo json_encode($endereco[$k]["view"]);
			echo json_encode($endereco[$k]["adm_assunto"]);
			echo json_encode($endereco[$k]["adm_orgao_responsavel"]);
			echo json_encode($endereco[$k]["adm_modo_de_envio"]);
			echo json_encode($endereco[$k]["adm_data_de_envio"]);
			echo json_encode($endereco[$k]["adm_historico"]);
			echo json_encode($endereco[$k]["adm_data_conclusao"]);
			echo json_encode($endereco[$k]["longitude"]);
			echo json_encode($endereco[$k]["latitude"]);
*/
?>