<?php
ini_set('default_charset', 'UTF-8');
/**
 * This example shows settings to use when sending via Google's Gmail servers.
 * This uses traditional id & password authentication - look at the gmail_xoauth.phps
 * example to see how to use XOAUTH2.
 * The IMAP section shows how to save this message to the 'Sent Mail' folder using IMAP commands.
 */

//Import PHPMailer classes into the global namespace
//use PHPMailer\PHPMailer\PHPMailer;


require 'mailer/PHPMailerAutoload.php';


$mensagem	= "Ocorrência número ".$cd_ocorrencia." Nome: ".$nome." É associado: ".$associado." E-mail: ".$email." Assunto: ".$assunto." Mensagem: ".$mensagem." Rua: ".$rua.", ".$numero." Bairro: ".$bairro." Data: ".$data." Tema: ".$tema;


	// Pega os valores do campo Mensagem

// Variável que junta os valores acima e monta o corpo do email

$Vai 		= "Nome: $nome\n\nE-mail: $email\n\nMensagem: $mensagem\n";



define('GUSER', 'naoresponda@amejardins.com.br');	// <-- Insira aqui o seu GMail
define('GPWD', '@bc123!@2018');		// <-- Insira aqui a senha do seu GMail

function smtpmailer($para, $de, $de_nome, $assunto, $corpo) { 
	global $error;
	$mail = new PHPMailer();
	$mail->IsSMTP();		// Ativar SMTP
	$mail->SMTPDebug = 0;		// Debugar: 1 = erros e mensagens, 2 = mensagens apenas
	$mail->SMTPAuth = true;		// Autenticação ativada
	$mail->SMTPSecure = 'ssl';	// SSL REQUERIDO pelo GMail
	$mail->Host = 'email-ssl.com.br';	// SMTP utilizado
	$mail->Port = 465;  		// A porta 587 deverá estar aberta em seu servidor
	$mail->Username = GUSER;
	$mail->Password = GPWD;
	$mail->SetFrom($de, $de_nome);
	$mail->Subject = $assunto;
	$mail->Body = $corpo;
	$mail->AddAddress($para);
	if(!$mail->Send()) {
		$error = 'Mail error: '.$mail->ErrorInfo; 
		return false;
	} else {
		//$error = 'Mensagem enviada!';
		return true;
	}
}

// Insira abaixo o email que irá receber a mensagem, o email que irá enviar (o mesmo da variável GUSER),  o nome do email que envia a mensagem, o Assunto da mensagem e por último a variável com o corpo do email.

 if (smtpmailer('fmazevedo@gmail.com', 'naoresponda@amejardins.com.br', 'Amejardins', 'NOVO ITEM ENVIADO', $Vai)) {

	//Header("location:http://powerlab.espm.br/amejardins/index.php"); // Redireciona para uma página de obrigado.

}
if (!empty($error)) echo $error;
?>