<?php

include "requerLogin.php";

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
<style>
body {
    font-family: helvetica;
}
table {
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #bbbbbb;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #f8f8f8;
}
tr:nth-child(odd) {
    background-color: #fefefe;
}
tr:nth-child(1) {
    background-color: #222;
	color: #eaeaea;
}
</style>
</head>
<body>

<?php
		//!
		$chnome 		= str_replace("'", "''", $_REQUEST['nome']);
		$chassociado	= str_replace("'", "''", $_REQUEST['associado']);
		$chemail 		= str_replace("'", "''", $_REQUEST['email']);
		$chassunto		= str_replace("'", "''", $_REQUEST['assunto']);
		$chmensagem		= str_replace("'", "''", $_REQUEST['mensagem']);
		$chendereco		= str_replace("'", "''", $_REQUEST['endereco']);
		$chbairro		= str_replace("'", "''", $_REQUEST['bairro']);
		$chtema 		= str_replace("'", "''", $_REQUEST['tema']);
		$chdata			= str_replace("'", "''", $_REQUEST['data']);
		$chstatus		= str_replace("'", "''", $_REQUEST['status']);
		$chview			= str_replace("'", "''", $_REQUEST['view']);
	//	$where			= str_replace("'", "''", $_REQUEST['where']);
		
		
		if($filtro_bairro != "" || $filtro_tema != ""){
			if($filtro_bairro != "" && $filtro_tema != ""){
				$where = " WHERE bairro='".$filtro_bairro."' and tema='".$filtro_tema."' ";
			}
			else if($filtro_bairro != "" && $filtro_tema == ""){
				$where = " WHERE bairro='".$filtro_bairro."' ";
			}
			if ($filtro_tema != "" && $filtro_bairro == ""){
				$where = " WHERE tema='".$filtro_tema."' ";
			}
		}
		
		if($chnome 		== 0 &&
		   $chassociado == 0 &&
		   $chemail 	== 0 &&
		   $chassunto 	== 0 &&
		   $chmensagem 	== 0 &&
		   $chendereco	== 0 &&
		   $chbairro	== 0 &&
		   $chtema 	    == 0 &&
		   $chdata		== 0 &&
		   $chstatus	== 0 &&
		   $chview		== 0){
			$chnome 	 = 1;
			$chassociado = 1;
			$chemail 	 = 1;
			$chassunto 	 = 1;
			$chmensagem  = 1;
			$chendereco	 = 1;
			$chbairro	 = 1;
			$chtema 	 = 1;
			$chdata		 = 1;
			$chstatus	 = 1;
			$chview		 = 1;
		}
		
		
?>
<a href="index.php">voltar ao mapa</a>
<h2 style="text-align:center; margin:0;">Relatório</h2>
<form action="relatorio.php" method="get">
<input disabled checked type="checkbox">Código
<input <?php if($chnome == 1){echo "checked";} ?> type="checkbox" value="1" name="nome">Nome
<input <?php if($chassociado == 1){echo "checked";} ?>  type="checkbox" value="1" name="associado">Associado
<input <?php if($chemail == 1){echo "checked";} ?>  type="checkbox" value="1" name="email">E-mail
<input <?php if($chassunto == 1){echo "checked";} ?>  type="checkbox" value="1" name="assunto">Assunto
<input <?php if($chmensagem == 1){echo "checked";} ?>  type="checkbox" value="1" name="mensagem">Mensagem
<input <?php if($chendereco == 1){echo "checked";} ?>  type="checkbox" value="1" name="endereco">Endereço
<input <?php if($chbairro == 1){echo "checked";} ?>  type="checkbox" value="1" name="bairro">Bairro
<input <?php if($chtema == 1){echo "checked";} ?>  type="checkbox" value="1" name="tema">Tema
<input <?php if($chdata == 1){echo "checked";} ?>  type="checkbox" value="1" name="data">Data
<input <?php if($chstatus == 1){echo "checked";} ?>  type="checkbox" value="1" name="status">Status
<input <?php if($chview == 1){echo "checked";} ?>  type="checkbox" value="1" name="view">Visualizações
<select name="filtro_bairro" class="filtrarr">
	<option selected value>FILTRAR BAIRRO</option>
	<option value="jardim_america">Jardim América</option>
	<option value="jardim_europa">Jardim Europa</option>
	<option value="jardim_paulista">Jardim Paulista</option>
	<option value="jardim_paulistano">Jardim Paulistano</option>
</select>
<select name="filtro_tema" style="min-height: 20px;">
	<option selected value>FILTRAR TEMA</option>
	<option value="acessibilidade">Acessibilidade</option>
	<option value="areas_verdes">Áreas Verdes</option>
	<option value="seguranca_publica">Segurança Pública</option>
	<option value="transito">Trânsito</option>
	<option value="uso_irregular_do_solo">Uso Irregular do Solo</option>
	<option value="zeladoria_urbana">Zeladoria Urbana</option>
	<option value="outros">Outros</option>
</select>
<input type="submit" value="ATUALIZAR">
</form>


<?php

echo "<table>
	  <tr>
			  <th>Código</th>";
		if($chnome == 1)
		echo "<th>Nome</th>";
		if($chassociado == 1)
		echo "<th>Associado</th>";
		if($chemail == 1)
		echo "<th>E-mail</th>";
		if($chassunto == 1)
		echo "<th>Assunto</th>";
		if($chmensagem == 1)
		echo "<th>Mensagem</th>";
		if($chendereco == 1)
		echo "<th>Endereço</th>";
		if($chbairro == 1)
		echo "<th>Bairro</th>";
		if($chtema == 1)
		echo "<th>Tema</th>";
		if($chdata == 1)
		echo "<th>Data</th>";
		if($chstatus == 1)
		echo "<th>Status</th>";
		if($chview == 1)
		echo "<th>Visualizações</th>";

	include "conexao.php";
	
	$consulta = 
		"select cd_ocorrencia, nome, associado, email, assunto, mensagem, numero, rua, bairro, data, tema, status, view
		from ocorrencia ".$where." order by data desc";




	$resultado = mysqli_query($conexao, $consulta) or die ("Não foi possível realizar a consulta ao banco de dados");
	
	echo "<div id='content3'>";

	while ($linha=mysqli_fetch_array($resultado)) {
		
		$cd_ocorrencia  = $linha['cd_ocorrencia'];
		$nome 			= $linha['nome'];
		$associado		= $linha['associado'];
		$email 			= $linha['email'];
		$assunto		= $linha['assunto'];
		$mensagem		= $linha['mensagem'];
		$rua			= $linha['rua'];
		$numero			= $linha['numero'];
		$bairro  		= $linha['bairro'];
		$tema 			= $linha['tema'];
		$data			= $linha['data'];
		$status			= $linha['status'];
		$view			= $linha['view'];
		
		if ($associado == "nao") {
			$associado = "Não";
			
		} else if ($associado == "sim") {
			$associado = "Sim";
		} else {
			$associado = "Quero me associar";
		}
		
		switch ($bairro) {
			case "jardim_america":
				$bairro = "Jardim América";
				$cor_bairro = "steelBlue";
				break;
			case "jardim_europa":
				$bairro = "Jardim Europa";
				$cor_bairro = "darkRed";
				break;
			case "jardim_paulista":
				$bairro = "Jardim Paulista";
				$cor_bairro = "darkGreen";
				break;
			case "jardim_paulistano":
				$bairro = "Jardim Paulistano";
				$cor_bairro = "darkOrange";
				break;
			default:
				$bairro = "Erro";
				$cor_bairro = "black";
		}
		
		switch ($tema) {
			case "acessibilidade":
				$tema = "Acessibilidade";
				$cor_tema = "purple";
				break;
			case "areas_verdes":
				$tema = "Áreas Verdes";
				//
				$cor_tema = "#00dd00";
				break;
			case "seguranca_publica":
				$tema = "Segurança Pública";
				//amarelo
				$cor_tema = "goldenRod";
				break;
			case "transito":
				$tema = "Trânsito";
				//vermelho
				$cor_tema = "red";
				break;
			case "uso_irregular_do_solo":
				$tema = "Uso Irregular do Solo";
				//
				$cor_tema = "#4286f4";
				break;
			case "zeladoria_urbana":
				$tema = "Zeladoria Urbana";
				//laranja
				$cor_tema = "orange";
				break;
			case "outros":
				$tema = "Outros";
				//preto
				$cor_tema = "black";
				break;
			default:
				$tema = "Erro";
				$cor_tema = "#555";
				break;
		}
		
		$datanova = date("d/m/Y", strtotime($data));
		
		switch($status){
			case 0:
				$status = 'Recebido';
				break;
			case 1:
				$status = 'Postado';
				break;
			case 2:
				$status = 'Concluído';
				break;
			case 3:
				$status = 'Negado';
				break;
			default:
				$status = 'Erro';
				break;
		}
		
	echo "
  
	  <tr>
		<th><a href=caso.php?cd_ocorrencia=$cd_ocorrencia>$cd_ocorrencia</a></th>
		";
		if($chnome == 1)
		echo "<th>$nome</th>";
		if($chassociado == 1)
		echo "<th>$associado</th>";
		if($chemail == 1)
		echo "<th>$email</th>";
		if($chassunto == 1)
		echo "<th>$assunto</th>";
		if($chmensagem == 1)
		echo "<th>$mensagem</th>";
		if($chendereco == 1) 
		echo "<th>$rua, $numero</th>";
		if($chbairro == 1)
		echo "<th><p style='color:" . $cor_bairro . ";'>$bairro</p></th>";
		if($chtema == 1)
		echo "<th><p style='color:" . $cor_tema . ";'>$tema</th>";
		if($chdata == 1)
		echo "<th>$datanova</th>";
		if($chstatus == 1)
		echo "<th>$status</th>";
		if($chview == 1)
		echo "<th>$view</th>";
		echo "
	  </tr>";
  
	

	}
	
	echo "</table>";
?>


</body>
</html>