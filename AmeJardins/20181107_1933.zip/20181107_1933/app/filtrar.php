<?php 

require("dbcontroller.php");
$dbController = new DBController();

$bairro = $_REQUEST['bairro'];
$tema 	= $_REQUEST['tema'];
$adm	= $_REQUEST['adm'];
/*
if ($bairro == '' && $tema == '') {$consulta = ""}
if ($bairro != '' && $tema != '') {$consulta = "where bairro like '$bairro' and tema like '$tema'";}
if ($bairro != '' && $tema == '') {$consulta = "where bairro like '$bairro'";}
if ($bairro == '' && $tema != '') {$consulta = "where tema like '$tema'";}
*/
if ($bairro == '' && $tema == '') {
	$consulta = "";
	$todos = 1;
}
else {
	if ($tema == '') $consulta = "where bairro like '$bairro'";
	else {
		if ($bairro == '') $consulta = "where tema like '$tema'";

		else $consulta = "where bairro like '$bairro' and tema like '$tema'";
	}
}



include "filtrado.php";

?>