<!doctype html>
<html>
  <head>
  <meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1.0">
	<!--<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">-->
    <title>Ame Jardins</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        margin: 0;
        padding: 0;
      }
	  body {
		  font-family :Arial;
	  }
	  #map-layer {
		  margin: 0 auto;
		  max-width: 100%;
		  min-height: 90vh;
	  }
    </style>
	 <!-- Bootstrap -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- font awesome for icons -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/animate.css" rel="stylesheet" type="text/css" media="screen"> 
        <!-- Revolution Style-sheet -->
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/css/settings.css">
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/css/rev-style.css">
        <!--owl carousel css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/yamm.css" rel="stylesheet" type="text/css">
        <!--cube css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css">
        <!-- custom css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/style.css?v=1" rel="stylesheet" type="text/css" media="screen">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
  </head>
  <body class="page-template page-template-fazemos page-template-fazemos-php page page-id-67 group-blog">
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78743991-3', 'auto');
ga('send', 'pageview');

</script>
<div class="navbar navbar-default navbar-static-top yamm sticky " style="background-color:#ECF3F8" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="http://amejardins.com.br/wp-content/themes/ametema/img/logo.png" alt="Ame Jardins"></a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="http://amejardins.com.br">Home</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/quem-somos">Quem Somos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/o-que-fazemos">O Que Fazemos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/associe-se">Associe-se</a> 
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Jardins <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="http://amejardins.com.br/area-de-cobertura">Área de Cobertura</a></li>
                                <li><a href="http://amejardins.com.br/historia">História</a></li>
                                <li><a href="http://amejardins.com.br/dicas">Dicas</a></li>
                            </ul>
							
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/fale-conosco">Fale Conosco</a> 
                        </li> 
						<li class="">
                            <a href="http://amejardins.com.br/noticias">Notícias</a>
                        </li>
						<li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ocorrências <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="index.php">Mapa de Ocorrências</a></li>
                                <li><a href="criar.php">Registro de Ocorrência</a></li>
                            </ul>
							
                        </li>
						<li>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.facebook.com/AMEJARDINS" target="_blank"><i class="fa fa-facebook-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.youtube.com/channel/UCGG0rEpCbiJnOHCc1j55GLg" target="_blank"><i class="fa fa-youtube-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.instagram.com/amejardins/" target="_blank"><i class="fa fa-instagram"></i></a>
						</li>
						</ul>
                </div><!--/.nav-collapse -->
            </div><!--container-->
        </div><!--navbar-default--><style>
.tjust p{
	text-align:justify;
	padding-right:20px
}
input {
		  background-color: transparent;
		  border-color: #000;
		  border: 1px solid;
		  border-radius: 2px;
		  -webkit-transition: background-color 200ms,color 200ms; /* For Safari 3.1 to 6.0 */
	      transition: background-color 200ms,color 200ms;
	  }
	  input:hover {
		  background-color: #000;
		  color: #fff;
		  
	  }
#rodape {
		clear:both;
		min-height: 500px;
		width: 90%;
		margin: 0 auto;
	}
@media(min-width:700px) {
	#rodape {
		clear:both;
		min-height: 500px;
		width: 60%;
		margin: 0 auto;
	}
}
</style>
 <div class="breadcrumb-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Ocorrência</h4>
                    </div>
                    
                </div>
            </div>
        </div><!--breadcrumbs-->
		<div class="divide80"></div>
<div id="rodape" style="">
<?php 

include "../conexao.php";

$cd_ocorrencia = $_REQUEST['cd_ocorrencia'];


if(file_exists('../uploads/'.$cd_ocorrencia.'.jpg')) {
	$imagem =  '../uploads/'.$cd_ocorrencia.'.jpg';
}
else {
	$imagem = '../uploads/_noimg.jpg';
}

$consulta = 
	"select
	email, assunto, mensagem, rua, numero, bairro, tema, data, status, view
	from ocorrencia 
    where  cd_ocorrencia = $cd_ocorrencia";




$resultado = mysqli_query($conexao, $consulta) or die ("Não foi possível realizar a consulta ao banco de dados");

// Agora iremos "obter" cada campo da notícia e organizar no HTML 
echo "<div id='content3'>";

while ($linha=mysqli_fetch_array($resultado)) {

$email 		= $linha['email'];
$assunto	= $linha['assunto'];
$mensagem	= $linha['mensagem'];
$rua		= $linha['rua'];
$numero		= $linha['numero'];
$bairro  	= $linha['bairro'];
$tema 		= $linha['tema'];
$data		= $linha['data'];
$status		= $linha['status'];
$view		= $linha['view'];


switch ($bairro) {
	case "jardim_america":
		$bairro = "Jardim América";
		break;
	case "jardim_europa":
		$bairro = "Jardim Europa";
		break;
	case "jardim_paulista":
		$bairro = "Jardim Paulista";
		break;
	case "jardim_paulistano":
		$bairro = "Jardim Paulistano";
}

//$novadata = substr($data,8,2) . "/" .substr($data,5,2) . "/" . substr($data,0,4); 
//$novahora = substr($hora,0,2) . "h" .substr($hora,3,2) . "min"; 

//echo "<div style='float: left'>";
//echo "<b>Código do Produto</b>: $cd_produto"; 
//echo "<br>";
echo "	<div id='ocorrencia' style='max-width: 780px;float:left;'>
				
				
				<h3 style='font-size:30px;'>$assunto</h3>
				<div id= 'statusocorrencia' style='margin-left: 4%,'>
					<p>$mensagem</p>
					<p>Local: $rua, $numero - $bairro<br>
					   Data: $data<br>
					   Visualizações: $view</p>
					<form action='editar_caso.php' method='post'>
						<input hidden value='$cd_ocorrencia' name='cd_ocorrencia'>
						<input type='submit' value='Editar'>
					</form>
				</div>
				
				<div id= 'fotoocorrencia' style='height: 240px; background-color: tranparent;float:left;margin-left: 20px;margin-bottom: 20px; padding: 3px;'>
					<img src='$imagem' height='240' width='240'></img>
				
				</div>
				
		</div>
		
		
		
		<!-- FOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTO-->
		<!-- FOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTO-->
		
		
		
		
		<!-- FOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTO-->
		<!-- FOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTOFOTO-->
		
		
		
		<hr style= 'clear: both;'>
		<h3 style='font-size:25px;'> Comentários</h3>";
//echo "<b>Postado em</b>: $data às $hora"; 
//echo "<br>";

}


/* ------ COMENTARIOS ---------
echo "<div id='comentarios' style='width:100%; min-height: 100px;'>";
		$conexao = mysqli_connect(localhost,"root","","amejardins") or die ("A conexão não foi executada com sucesso");
		
		$consulta = 
			"select u.nickname, c.comentario, c.data, c.hora
				from usuario u, comentario c
				where u.cd_usuario = c.cd_usuario and cd_ocorrencia = $cd_ocorrencia
				order by c.data desc;";
		
		$resultado = mysqli_query($conexao, $consulta) or die ("Não foi possível realizar a consulta ao banco de dados v2 (comentários)"); //Não foi possível realizar a consulta ao banco de dados v2
		
		while ($linha=mysqli_fetch_array($resultado)) {
		
		$nickname		= $linha['nickname'];
		$comentario 	= $linha['comentario'];
		$data			= $linha['data'];
		$hora			= $linha['hora'];
		
		
		
		
		
		echo "	<div id='comentario' style='width:100%; height: 100px;; line-height: 10px;'>
					<br><p style='font-size: 14px;'><a href='index.php?pagina=perfil.php&nickname=$nickname'><b>$nickname</b></a> - $data às $hora</p><br>
					<p>$comentario</p>
					<hr>
				</div>";
		}
echo	"</div></div></div>";
*/


	$update = "UPDATE ocorrencia SET view = view + 1 WHERE cd_ocorrencia=$cd_ocorrencia"; 
	$resultado_update = mysqli_query($conexao, $update) or die ("Houve erro no UPDATE!");

?></div>
</div>
<div class="divide60"></div>
        <footer class="footer-light-1">

			<div class="footer-copyright text-center">
                Ame Jardins &copy; 2017. Todos os direitos reservados.
				<br>Rua Estados Unidos, 1.205 - Jd. América | CEP: 01427-000 |  (11) 3097-0911 | amejardins@amejardins.com.br
            </div>
        </footer><!--default footer end here-->

        <!--scripts and plugins -->
        <!--must need plugin jquery-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.min.js"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery-migrate.min.js"></script> 
        <!--bootstrap js plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>       
        <!--easing plugin for smooth scroll-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/wow.min.js" type="text/javascript"></script> 
        <!--owl carousel slider-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>        
        <!--customizable plugin edit according to your needs-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/revolution-custom.js"></script>
        <!--cube portfolio plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/cube-portfolio.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/pace.min.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/jasny/jasny-bootstrap.min.js"></script>

        
        <!--cantact form script-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jqBootstrapValidation.js" type="text/javascript"></script>
		<script>
			function processAutoheight(){
				
				$(".autoheight").each(function(){
					var maxHeight = 0;
					maxHeight = $(this).parents(".row").children(".hpadrao").outerHeight(true);
					$(this).height(maxHeight);
				})
					
			}


			$(document).ready(function() {

			$(".cep").inputmask({
				mask: '99999-999'
			});
			$(".cpf").inputmask({
				mask: '999.999.999-99'
			});
			$(".cnpj").inputmask({
				mask: '999.999.999/9999-99'
			});
			$(".tel").inputmask({
				mask: '(99) 9999-9999?9'
			});
    $(window).resize(function() { processAutoheight(); });

    $(document).resize(function() { processAutoheight(); });

    processAutoheight();
	$("#selectpss").on('change', function() {
		var valor = $(this).val();
		$(".formulario").hide();
		$("#"+valor).show();
	});
});
		</script>
  </body>
</html>