<?php

function checaLogin() {
	$cookie = $_COOKIE["usuario"];
	if ($cookie && strlen($cookie) == 58) {
		$id = hexdec(substr($cookie, 0, 8));
		$token = str_replace("'", "''", substr($cookie, 8));
		if ($token) {
			include "conexao.php";
			$resultado = mysqli_query($conexao, "SELECT token FROM usuario WHERE id = $id");
			while ($linha = mysqli_fetch_array($resultado)) {
				if ($linha["token"] == $token) {
					return true;
				}
			}
		}
	}
	return false;
}

?>
