<?php

include "requerLogin.php";

?>
<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ame Jardins</title>

        <!-- Bootstrap -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- font awesome for icons -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- flex slider css -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/flexslider.css" rel="stylesheet" type="text/css" media="screen">
        <!-- animated css  -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/animate.css" rel="stylesheet" type="text/css" media="screen"> 
        <!-- Revolution Style-sheet -->
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/css/settings.css">
        <link rel="stylesheet" type="text/css" href="http://amejardins.com.br/wp-content/themes/ametema/css/rev-style.css">
        <!--owl carousel css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.carousel.css" rel="stylesheet" type="text/css" media="screen">
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/owl.theme.css" rel="stylesheet" type="text/css" media="screen">
        <!--mega menu -->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/css/yamm.css" rel="stylesheet" type="text/css">
        <!--cube css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/css/cubeportfolio.min.css" rel="stylesheet" type="text/css">
        <!-- custom css-->
        <link href="http://amejardins.com.br/wp-content/themes/ametema/style.css?v=1" rel="stylesheet" type="text/css" media="screen">
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>

<body class="page-template page-template-fazemos page-template-fazemos-php page page-id-67 group-blog">
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-78743991-3', 'auto');
ga('send', 'pageview');

	
	function getCoords() {
        
		var geocoder = new google.maps.Geocoder();
		
		var endereco = 'Brasil, SP, São Paulo ' + document.form1.bairro.value + ' ' + document.form1.rua.value + ' ' + document.form1.numero.value;
		
        geocoder.geocode({'address': endereco}, function(results, status) {
          if (status === 'OK') {
			var lat = results[0].geometry.location.lat();
			var lng = results[0].geometry.location.lng();
			//document.f.coords.value = results[0].formatted_address;
			if (-23.52974465 > lat && lat > -23.62005445 &&
			     -46.6222729 > lng && lng > -46.72484057) {
				
				document.form1.coordenadalat.value = lat;
				document.form1.coordenadalng.value = lng;
			
			} else {
				endereco = document.form1.rua.value + ' , ' + document.form1.numero.value + ' - ' + document.form1.bairro.value + 'paraiso vila mariana pinheiros itaim bibi vila olimpia São Paulo, Brasil';
				geocoder.geocode({'address': endereco}, function(results, status) {
				  if (status === 'OK') {
					var lat = results[0].geometry.location.lat();
					var lng = results[0].geometry.location.lng();
					//document.f.coords.value = results[0].formatted_address;
					if (-23.52974465 > lat && lat > -23.62005445 &&
						 -46.6222729 > lng && lng > -46.72484057) {
						
						document.form1.coordenadalat.value = lat;
						document.form1.coordenadalng.value = lng;
					
					}
					
				  } else {
					alert('Geocode was not successful for the following reason: ' + status);
				  }
				});
				
			}
			
			
          } else {
            alert('Geocode was not successful for the following reason: ' + status);
          }
        });
        
    }
</script>
<script async defer
		src="https://maps.googleapis.com/maps/api/js?key=<?php echo AIzaSyA6ysBoiWNEiQKRzPgymJroG_j_U2xPnnM; ?>">
    </script>
<div class="navbar navbar-default navbar-static-top yamm sticky " style="background-color:#ECF3F8" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="http://amejardins.com.br/wp-content/themes/ametema/img/logo.png" alt="Ame Jardins"></a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="http://amejardins.com.br">Home</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/quem-somos">Quem Somos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/o-que-fazemos">O Que Fazemos</a> 
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/associe-se">Associe-se</a> 
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Jardins <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="http://amejardins.com.br/area-de-cobertura">Área de Cobertura</a></li>
                                <li><a href="http://amejardins.com.br/historia">História</a></li>
                                <li><a href="http://amejardins.com.br/dicas">Dicas</a></li>
                            </ul>
							
                        </li>
						<li class="">
                            <a href="http://amejardins.com.br/fale-conosco">Fale Conosco</a> 
                        </li> 
						<li class="">
                            <a href="http://amejardins.com.br/noticias">Notícias</a>
                        </li>
						<li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ocorrências <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="index.php">Mapa de Ocorrências</a></li>
                                <li><a href="criar.php">Registro de Ocorrência</a></li>
                            </ul>
							
                        </li>
						<li>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.facebook.com/AMEJARDINS" target="_blank"><i class="fa fa-facebook-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.youtube.com/channel/UCGG0rEpCbiJnOHCc1j55GLg" target="_blank"><i class="fa fa-youtube-square"></i></a>
							<a class="pull-left" style="padding-left:3px;padding-right:3px" href="https://www.instagram.com/amejardins/" target="_blank"><i class="fa fa-instagram"></i></a>
						</li>
						</ul>
                </div><!--/.nav-collapse -->
            </div><!--container-->
        </div><!--navbar-default--><style>
.tjust p{
	text-align:justify;
	padding-right:20px
}
.botao {
		  background-color: transparent;
		  border-color: #000;
		  border: 1px solid;
		  border-radius: 2px;
		  -webkit-transition: background-color 200ms,color 200ms; /* For Safari 3.1 to 6.0 */
	      transition: background-color 200ms,color 200ms;
	  }
	  .botao:hover {
		  background-color: #000;
		  color: #fff;
		  
	  }
.formulariospmais {
	max-width: 300px;
	margin : 0 auto;
}
.formulariospmais form label {
	display:block;
}
.formulariospmais form p {
	margin: 0;
}
.formulariospmais form button, .formulariospmais form input, .formulariospmais form textarea, .formulariospmais form select{
	width: 100%;
}
@media(max-width:600px) {
	.formulariospmais {
	min-width: 200px;
	margin : 0 auto;
}
}
</style>
<div class="breadcrumb-wrap">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>Registro de Ocorrência</h4>
                    </div>
                    
                </div>
            </div>
        </div><!--breadcrumbs-->
		<div class="divide80"></div>
		<div class="formulariospmais">
			
			
			
			
			<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
			<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
			<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
			<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
		
		<form id="form1" name="form1" align="center" action="inserir.php" method="post"  enctype="multipart/form-data">
			<p>*Nome:</p><input name="nome" type="text" size="30" style="height: 30;" required><br><br>
			*Associado:
			<select name="associado" required>
	    		<option disabled selected value>SELECIONAR</option>
	    		<option value="sim">Sim</option>
		    	<option value="nao">Não</option>
		    	<option value="quero_me_associar">Quero me associar</option>
			</select>
   			<br><br>
			<p>*E-mail:</p><input name="email" type="text" size="30" style="height: 30;" required><br><br>
			<p>*Assunto:</p><input name="assunto" type="text" size="30" style="height: 30;" required><br><br>
			<p>*Mensagem:</p><textarea name="mensagem" rows="5" cols="30"></textarea><br><br>
			<p>*Rua:<input name="rua" type="text" size="25" style="height: 30;" required onBlur="getCoords();">
			<br>Nº:<input name="numero" type="number" size="1px" style="height: 30;" onBlur="getCoords();"></p>
			*Bairro:
			<select name="bairro" required onChange="getCoords();">
	    		<option disabled selected value>SELECIONAR</option>
		    	<option value="jardim_america">Jardim América</option>
	    		<option value="jardim_europa">Jardim Europa</option>
		    	<option value="jardim_paulista">Jardim Paulista</option>
		    	<option value="jardim_paulistano">Jardim Paulistano</option>
			</select>
   			<br><br>
			<p>Data:<br></p>
			<input type="date" name="data" required><br><br>
    		*Tema:
	    	<select name="tema" required>
	    		<option disabled selected value>SELECIONAR</option>
		    	<option value="acessibilidade">Acessibilidade</option>
		    	<option value="areas_verdes">Áreas Verdes</option>
		    	<option value="seguranca_publica">Segurança Pública</option>
		    	<option value="transito">Trânsito</option>
		    	<option value="uso_irregular_do_solo">Uso Irregular do Solo</option>
		    	<option value="zeladoria_urbana">Zeladoria Urbana</option>
		    	<option value="outros">Outros</option>
			</select>
			<br>
			
			
			
			<input type="text" name="coordenadalng" value="" readonly hidden>
			<input type="text" name="coordenadalat" value="" readonly hidden>
			
			
			
			<p>Foto:</p>
			<input type="file" name="fileToUpload" id="fileToUpload" style="margin: 0 auto;" value="">
			<br>
			
			<p>Campos marcados com * devem ser preenchidos</p>
			<br><br>
			<input type="submit" name="botao" value="CADASTRAR" class= "botao">
			<br><br>
		</form>
		
		</div>
		
		
		<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
		<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
		<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
		<!-- WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW -->
	
	
	
	
		<div class="divide60"></div>
        <footer class="footer-light-1">

			<div class="footer-copyright text-center">
                Ame Jardins &copy; 2017. Todos os direitos reservados.
				<br>Rua Estados Unidos, 1.205 - Jd. América | CEP: 01427-000 |  (11) 3097-0911 | amejardins@amejardins.com.br
            </div>
        </footer><!--default footer end here-->

        <!--scripts and plugins -->
        <!--must need plugin jquery-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.min.js"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery-migrate.min.js"></script> 
        <!--bootstrap js plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>       
        <!--easing plugin for smooth scroll-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.easing.1.3.min.js" type="text/javascript"></script>
        <!--sticky header-->
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.sticky.js"></script>
        <!--flex slider plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.flexslider-min.js" type="text/javascript"></script>
        <!--parallax background plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.stellar.min.js" type="text/javascript"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/waypoints.min.js"></script>
        <!--digit countdown plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.counterup.min.js" type="text/javascript"></script>
        <!--on scroll animation-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/wow.min.js" type="text/javascript"></script> 
        <!--owl carousel slider-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/owl.carousel.min.js" type="text/javascript"></script>
        <!--popup js-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
        <!--you tube player-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jquery.mb.YTPlayer.min.js" type="text/javascript"></script>        
        <!--customizable plugin edit according to your needs-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="http://amejardins.com.br/wp-content/themes/ametema/js/revolution-custom.js"></script>
        <!--cube portfolio plugin-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/cubeportfolio/js/jquery.cubeportfolio.min.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/cube-portfolio.js" type="text/javascript"></script>
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/pace.min.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/custom.js" type="text/javascript"></script>
		<script src="http://amejardins.com.br/wp-content/themes/ametema/js/jasny/jasny-bootstrap.min.js"></script>

        
        <!--cantact form script-->
        <script src="http://amejardins.com.br/wp-content/themes/ametema/js/jqBootstrapValidation.js" type="text/javascript"></script>
		<script>
			function processAutoheight(){
				
				$(".autoheight").each(function(){
					var maxHeight = 0;
					maxHeight = $(this).parents(".row").children(".hpadrao").outerHeight(true);
					$(this).height(maxHeight);
				})
					
			}


			$(document).ready(function() {

			$(".cep").inputmask({
				mask: '99999-999'
			});
			$(".cpf").inputmask({
				mask: '999.999.999-99'
			});
			$(".cnpj").inputmask({
				mask: '999.999.999/9999-99'
			});
			$(".tel").inputmask({
				mask: '(99) 9999-9999?9'
			});
    $(window).resize(function() { processAutoheight(); });

    $(document).resize(function() { processAutoheight(); });

    processAutoheight();
	$("#selectpss").on('change', function() {
		var valor = $(this).val();
		$(".formulario").hide();
		$("#"+valor).show();
	});
});
		</script>
</body>
</html>